#!/bin/bash

source deployUtil.sh

declare local userName=dorfth
declare local destDir=jars
declare local artifactName=MDServer
declare local settingsName=SettingsMDServer.json
declare local csvName=ClosingPrices.csv
declare local csvSOD=gen.SOD.csv
declare local csvOrders=gen.Orders.csv
declare local csvFills=gen.Fills.csv

funcScpFileToHost() {
    declare local filename=$1
    funcScpFile . $filename $userName $destHost $destDir
}

funcDeployToHost() {
    declare local destHost=$1

    echo "Deploying to ${destHost}"
    funcDeployJar $artifactName $userName $destHost $destDir
    funcScpFileToHost $settingsName
    funcScpFileToHost $csvName
    funcScpFileToHost $csvSOD
    funcScpFileToHost $csvOrders
    funcScpFileToHost $csvFills
}

funcDeployToHost ubuntu2
funcDeployToHost ubuntu1

#funcDeployJar() {
#    local -r artifactName=$1
#    local -r userName=$2
#    local -r destHost=$3
#    local -r destDir=$4

#funcScpFile() {
#    local -r filePath=$1
#    local -r userName=$2
#    local -r destHost=$3
#    local -r destDir=$4

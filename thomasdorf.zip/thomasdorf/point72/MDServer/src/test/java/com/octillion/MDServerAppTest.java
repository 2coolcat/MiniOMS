package com.octillion;

import com.octillion.OmsModels.ModelFill;
import com.octillion.OmsModels.ModelMarketData;
import com.octillion.OmsModels.ModelOrder;
import org.junit.Test;

import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

public class MDServerAppTest
{
    Random theRandom = new Random();

    int getNextOrderID()
    {
        return theNextOrderID++;
    }
    int theNextOrderID = 1000;

    long getNextTime()
    {
        theNextTime += theRandom.nextInt(3);
        return theNextTime;
    }

    String getNextBookName()
    {
        theNextBookNameIndex++;
        theNextBookNameIndex = theNextBookNameIndex % theBookNames.size();
        return theBookNames.get(theNextBookNameIndex);
    }
    int theNextBookNameIndex = 0;
    List<String> theBookNames = Arrays.asList("Book1", "Book2", "Book3");

    long theNextTime = CsvUtils.parseDateTimeToEpochSeconds("2020-02-27 09:30:01");

    @Test
    public void runTestFiles()
    {
        try
        {
            // gives 09:30 ~ 10:00
            buildTestFiles(10, 20, 1000);

            // gives 09:30 ~ 12:00
//            buildTestFiles(10, 20, 4000);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    /**
     * Creates 3 files suitable for running with OmsServer
     * gen.SOD.csv
     * gen.Orders.csv
     * gen.Fills.csv
     *
     * Uses the ClosingPrices.csv file to select Symbols
     * and get reference prices from
     *
     * @param aNumTestSymbols Number of symbols to represent in the files
     * @param aTopSharesThousands Cap on the umber of thousands of shares for
     *                            SOD Positions
     * @param aNumActions Total number of iterations to run
     * @throws Exception
     */
    private void buildTestFiles(
        int aNumTestSymbols,
        int aTopSharesThousands,
        int aNumActions) throws Exception
    {
        final Queue<TestSymbol> testSymbolQueue = new ArrayDeque<>();

        FeedMarketDataCsv feed = new FeedMarketDataCsv("ClosingPrices.csv");

        PrintWriter sod = new PrintWriter("gen.SOD.csv", "UTF-8");
        PrintWriter orders = new PrintWriter("gen.Orders.csv", "UTF-8");
        PrintWriter fills = new PrintWriter("gen.Fills.csv", "UTF-8");

        feed.processEntries(md ->
        {
            if (testSymbolQueue.size() < aNumTestSymbols)
            {
                for (int i=0; i<theBookNames.size(); i++)
                {
                    if (theRandom.nextInt(100) > 40 + i * 10)
                    {
                        addTestSybolForBook(
                            testSymbolQueue,
                            md,
                            getNextBookName(),
                            aTopSharesThousands,
                            sod,
                            orders,
                            fills);
                    }
                }
            }
        });

        sod.close();

        for (int i=0; i < aNumActions; i++)
        {
            TestSymbol t = testSymbolQueue.remove();
            t.takeNextAction();
            testSymbolQueue.add(t);
        }

        orders.close();
        fills.close();
    }

    void addTestSybolForBook(
        Queue<TestSymbol> aQ,
        ModelMarketData md,
        String aBookName,
        int aTopSharesThousands,
        PrintWriter sod,
        PrintWriter orders,
        PrintWriter fills)
    {
        ModelOrder templateOrder = ModelOrder
            .newBuilder()
            .setTradeDateUTC(getNextTime())
            .setOrderId(0)
            .setBookName(aBookName)
            .setTicker(md.getTicker())
            .setSide(ModelOrder.EnumSide.UNDEF_SIDE)
            .setSharesOrder(0)
            .setSharesToGo(0)
            .setPrice4(md.getPrice4PrevClose())
            .build();

        aQ.add(new TestSymbol(
            templateOrder,
            md.getPrice4PrevClose(),
            aTopSharesThousands,
            this::getNextTime,
            this::getNextOrderID,
            o ->
            {
                String timeString = CsvUtils.longAsDateTimeString(o.getTradeDateUTC());

                orders.printf("%s,%d,%s,%s,%s,%s,%s,%f\n",
                    timeString,
                    o.getOrderId(),
                    o.getBookName(),
                    o.getTicker(),
                    (o.getAction() == ModelOrder.EnumAction.CANCELLED) ? "TRUE" : "FALSE",
                    o.getSide().toString(),
                    o.getSharesOrder(),
                    o.getPrice4() / 10000.0);
            },
            f ->
            {
                fills.printf("%s,%d,%s,%s,%d\n",
                    CsvUtils.longAsDateTimeString(f.getTradeDateUTC()),
                    f.getOrderId(),
                    f.getBookName(),
                    f.getTicker(),
                    f.getSharesFilled());
            }));

        sod.printf("2020-02-27,%s,%s,%d\n",
            templateOrder.getBookName(),
            templateOrder.getTicker(),
            theRandom.nextInt(20) * 1000 * (theRandom.nextBoolean() ? 1 : -1));
    }

    class TestSymbol
    {
        ModelOrder theModelOrderTemplate;
        int thePrice4Ref;

        Callable<Long> nextTime;
        Callable<Integer> nextOrderID;
        Consumer<ModelOrder> processOrder;
        Consumer<ModelFill> processFill;

        Stack<ModelOrder> BuySide = new Stack<>();
        Stack<ModelOrder> SellSide = new Stack<>();
        int theTopShareThousands;

        public TestSymbol(
            ModelOrder aModelOrderTemplate,
            int aPrice4Ref,
            int aTopShareThousands,
            Callable<Long> aNextTime,
            Callable<Integer> aNextOrderID,
            Consumer<ModelOrder> aProcessOrder,
            Consumer<ModelFill> aProcessFill)
        {
            theModelOrderTemplate = aModelOrderTemplate;
            thePrice4Ref = aPrice4Ref;
            theTopShareThousands = aTopShareThousands;
            nextTime = aNextTime;
            nextOrderID = aNextOrderID;
            processOrder = aProcessOrder;
            processFill = aProcessFill;
        }

        void addRandomOrder(boolean isBuy) throws Exception
        {
            Stack<ModelOrder> stack  = isBuy ? BuySide : SellSide;

            int sharesOrder = 1000 * (1 + theRandom.nextInt(theTopShareThousands));
            int randPrice = thePrice4Ref + (100 * (theRandom.nextInt(50)) * (isBuy ? -1 : 1));
            long nextOrderTime = nextTime.call();
            String timeString = CsvUtils.longAsDateTimeString(nextOrderTime);

            ModelOrder modelOrder = ModelOrder.newBuilder(theModelOrderTemplate)
                .setTradeDateUTC(nextOrderTime)
                .setOrderId(nextOrderID.call())
                .setSide(isBuy ? ModelOrder.EnumSide.BUY : ModelOrder.EnumSide.SELL)
                .setPrice4(randPrice)
                .setSharesOrder(sharesOrder)
                .setSharesToGo(sharesOrder)
                .build();

            processOrder.accept(modelOrder);
            stack.push(modelOrder);
        }

        void takeNextAction() throws Exception
        {
            if ((BuySide.size() < 3) || ((theRandom.nextInt(100) < 5) && (BuySide.size() < 6)))
            {
                addRandomOrder(true);
            }

            if ((SellSide.size() < 3) || ((theRandom.nextInt(100) < 5) && (SellSide.size() < 6)))
            {
                addRandomOrder(false);
            }

            createFillForSide(BuySide);
            createFillForSide(SellSide);

            cancelForSide(BuySide);
            cancelForSide(SellSide);
        }

        void cancelForSide(Stack<ModelOrder> orderStack) throws Exception
        {
            if (theRandom.nextInt(100) > 98)
            {
                ModelOrder modelOrderToCancel = orderStack.pop();

                processOrder.accept(ModelOrder.newBuilder(modelOrderToCancel)
                    .setTradeDateUTC(nextTime.call())
                    .setAction(ModelOrder.EnumAction.CANCELLED)
                    .build());
            }
        }

        void createFillForSide(Stack<ModelOrder> orderStack) throws Exception
        {
            ModelOrder topBuy = orderStack.pop();
            ModelOrder modBuy = createFillFor(topBuy);
            if (modBuy.getSharesToGo() > 0)
            {
                orderStack.push(modBuy);
            }
        }

        /**
         * Return modified ModelOrder
         */
        ModelOrder createFillFor(ModelOrder modelOrder) throws Exception
        {
            int sharesFilled = Math.min(modelOrder.getSharesToGo(), 100 * (1 + theRandom.nextInt(30)));

            processFill.accept(ModelFill.newBuilder()
                .setTradeDateUTC(nextTime.call())
                .setOrderId(modelOrder.getOrderId())
                .setBookName(modelOrder.getBookName())
                .setTicker(modelOrder.getTicker())
                .setSharesFilled(sharesFilled)
                .build());

            return ModelOrder.newBuilder(modelOrder)
                .setSharesToGo(modelOrder.getSharesToGo() - sharesFilled)
                .build();
        }
    }
}

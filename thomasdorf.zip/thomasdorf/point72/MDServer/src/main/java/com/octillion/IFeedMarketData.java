package com.octillion;

import com.octillion.OmsModels.ModelMarketData;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

public interface IFeedMarketData
{
    void processEntries(@NotNull Consumer<ModelMarketData> aConsumer);
}

package com.octillion;

import org.jetbrains.annotations.NotNull;
import com.octillion.OmsModels.ModelMarketData;

public interface IMDServer
{
    void sendMD(@NotNull ModelMarketData modelMD);
    void close();
}

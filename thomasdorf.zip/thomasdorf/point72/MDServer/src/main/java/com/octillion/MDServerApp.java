package com.octillion;

import java.util.Scanner;

public class MDServerApp
{
    private static String DEFAULT_SETTINGS_FILE = "SettingsMDServer.json";

    public static void main(String[] args)
    {
        String settingFile = (args.length == 1) ? args[0] : DEFAULT_SETTINGS_FILE;
        System.out.printf("MDServer is Running with Settings File: %s\n", settingFile);
        SettingsMDServer settingsMDServer = SettingsMDServer.FromJson(settingFile);
        System.out.println(settingsMDServer.toString());

        MDServerEngine engine = new MDServerEngine(
            new FeedMarketDataCsv(settingsMDServer.CvsFileMD),
            new MDServerRabbitMQ(settingsMDServer.SettingsRabbitMQ));

        engine.start();

        waitForUserExit();

        engine.stop();
    }

    private static void waitForUserExit()
    {
        Scanner sc = new Scanner(System.in);

        String input = "";

        while (!input.equalsIgnoreCase("q"))
        {
            System.out.print("<'Q' or 'q' to exit>: ");
            input = sc.next();
        }
    }
}

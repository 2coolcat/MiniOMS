package com.octillion;

import com.octillion.OmsModels.ModelMarketData;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class FeedMarketDataCsv implements IFeedMarketData
{
    private static Logger log = LoggerFactory.getLogger(FeedMarketDataCsv.class);

    private static int ITEMS_PER_LINE = 3;
    private static String CSV_COMMENT = "#";

    /**
     * tradeDateUTC
     */
    private static String FIRST_HEADER = ModelMarketData.getDescriptor().getFields().get(0).getName();

    private String theFilename;

    FeedMarketDataCsv(@NotNull String aFilename)
    {
        theFilename = aFilename;
    }

    /**
     * CSV lines are not processed if
     * wrong number of items,
     * an expected header or
     * begins with comment string
     * @param items The split items from a csv line
     * @return Return true if expected csv data format
     */
    private static boolean isValidCsvLine(@NotNull String[] items)
    {
        return
            (items.length == ITEMS_PER_LINE) &&
            !items[0].trim().equals(FIRST_HEADER) &&
            !items[0].trim().startsWith(CSV_COMMENT);
    }

    @Override
    public void processEntries(@NotNull Consumer<ModelMarketData> aConsumer)
    {
        try
        {
            try (Stream<String> stream = Files.lines(Paths.get(theFilename)))
            {
                stream.forEach(line ->
                {
                    String[] items = line.split(",");

                    if (isValidCsvLine(items))
                    {
                        ModelMarketData modelMD = ModelMarketData.newBuilder()
                            .setTradeDateUTC(CsvUtils.parseDateToEpochSeconds(items[0]))
                            .setTicker(items[1].trim())
                            .setPrice4PrevClose(CsvUtils.parsePrice4(items[2]))
                            .build();

                        aConsumer.accept(modelMD);
                    }
                });
            }
        }
        catch(IOException ex)
        {
            log.error("Could not find SOD file {}", theFilename);
            throw new RuntimeException(ex.getMessage());
        }
    }
}

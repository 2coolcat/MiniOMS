package com.octillion;

import com.octillion.OmsModels.ModelMarketData;
import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class MDServerRabbitMQ implements IMDServer
{
    private static Logger log = LoggerFactory.getLogger(MDServerRabbitMQ.class);

    private SettingsRabbitMQ theSettingsRabbitMQ;

    private Connection theConnection;
    private Channel theChannel;

    public MDServerRabbitMQ(SettingsRabbitMQ aSettingsRabbitMQ)
    {
        log.info("OmsServerRabbitMQ()");
        theSettingsRabbitMQ = aSettingsRabbitMQ;
    }

    @NotNull
    private Connection getConnection()
    {
        if (theConnection == null)
        {
            ConnectionFactory factory = new ConnectionFactory();
            // "guest"/"guest" is limited to localhost connections
            factory.setUsername(theSettingsRabbitMQ.UserName);
            factory.setPassword(theSettingsRabbitMQ.UserPass);
            factory.setVirtualHost(theSettingsRabbitMQ.VirtualHost);
            factory.setHost(theSettingsRabbitMQ.Hostname);
            factory.setPort(theSettingsRabbitMQ.Port);

            try
            {
                theConnection = factory.newConnection();
            }
            catch (IOException | TimeoutException ex)
            {
                theConnection = null;

                log.error("Failed to establish CONNECTION to RabbitMQ using {}\n{}",
                    theSettingsRabbitMQ,
                    ex.getMessage());

                throw new RuntimeException(ex.getMessage());
            }

            log.info("Established CONNECTION to RabbitMQ using {}", theSettingsRabbitMQ);
        }

        return theConnection;
    }

    @NotNull
    private Channel getChannel()
    {
        if (theChannel == null)
        {
            try
            {
                theChannel = getConnection().createChannel();
            }
            catch (IOException ex)
            {
                theChannel = null;

                log.error("Failed to establish CHANNEL on RabbitMQ using {}\n{}",
                    theSettingsRabbitMQ,
                    ex.getMessage());

                throw new RuntimeException(ex.getMessage());
            }

            log.info("Established CHANNEL on RabbitMQ using {}", theSettingsRabbitMQ);
        }

        return theChannel;
    }

    @Override
    public void sendMD(@NotNull ModelMarketData modelMD)
    {
        log.info("SendMD({})", modelMD);

        sendMessage(
            theSettingsRabbitMQ.ExchangeTopic,
            topicFromTicker(modelMD.getTicker()),
            null,
            modelMD.toByteArray());
    }

    /**
     * Topics have defined function for '.'
     * replace with '_'
     * @param aTicker A Ticker with embedded '.'
     * @return Returns a Ticker with '_' in place of '.'
     */
    private static String topicFromTicker(String aTicker)
    {
        return aTicker.replace('.', '_');
    }

    private void sendMessage(
        @NotNull String anExchangeName,
        @NotNull String aRoutingKey,
        @Nullable AMQP.BasicProperties aProperties,
        @NotNull byte[] aBytes)
    {
        try
        {
            getChannel().basicPublish(anExchangeName, aRoutingKey, aProperties, aBytes);
        }
        catch (IOException ex)
        {
            log.error("Failed to send RabbitMQ message on {} queue", aRoutingKey);
        }
    }

    @Override
    public void close()
    {
        if (theConnection != null)
        {
            try
            {
                getConnection().close();
            }
            catch (IOException ex)
            {
                log.error("Failed to close connection for RabbitMQ using {}\n{}",
                    theSettingsRabbitMQ,
                    ex.getMessage());
            }
        }
    }
}

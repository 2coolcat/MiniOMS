package com.octillion;

import com.octillion.OmsModels.ModelMarketData;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class MDServerEngine
{
    private static Logger log = LoggerFactory.getLogger(MDServerEngine.class);

    private final IFeedMarketData theFeedMarketData;
    private final IMDServer theMDServer;
    private Queue<ModelMarketData> theTickerQ = new ArrayDeque<>();

    private Timer theTimer = new Timer();
    private Random theRandom = new Random();

    public MDServerEngine(
        @NotNull IFeedMarketData aFeedMarketData,
        @NotNull IMDServer aMDServer)
    {
        log.info("MDServerEngine");
        theFeedMarketData = aFeedMarketData;
        theMDServer = aMDServer;
    }

    void start()
    {
        // read from csv
        theFeedMarketData.processEntries(this::processNewTicker);

        if (theTickerQ.size() == 0)
        {
            log.error("No valid Tickers found in MarketData source");
            throw new RuntimeException("No valid Tickers found in MarketData source");
        }

        // start a timer
        // start process to feed Orders and Fills
        theTimer.scheduleAtFixedRate(
            new TimerTask()
            {
                @Override
                public void run()
                {
                    sendNextMD();
                }
            },
            100,
            100);
    }

    /**
     * We get Previous Closing Price from csv
     * Set a random Opening price and Current Price
     * @param modelMD
     */
    private void processNewTicker(ModelMarketData modelMD)
    {
        int price4PrevClose = modelMD.getPrice4PrevClose();
        int price4Open = nextRandomPrice(
            price4PrevClose,
            100,
            (int)(price4PrevClose * 0.8),
            (int)(price4PrevClose * 1.2));

        theTickerQ.add(ModelMarketData.newBuilder(modelMD)
            .setPrice4Open(price4Open)
            .setPrice4Current(price4Open)
            .build());
    }

    private void sendNextMD()
    {
        log.info("sendNextMD");
        ModelMarketData updatedModelMD = updatePriceCurrent(theTickerQ.remove());
        theMDServer.sendMD(updatedModelMD);
        theTickerQ.add(updatedModelMD);
    }

    private ModelMarketData updatePriceCurrent(ModelMarketData modelMD)
    {
        int priceCurrent = modelMD.getPrice4Current();
        int nextPrice4 = nextRandomPrice(
            priceCurrent,
            1,
            (int)(modelMD.getPrice4Open() * 0.8),
            (int)(modelMD.getPrice4Open() * 1.2));

        return ModelMarketData.newBuilder(modelMD)
            .setPrice4Current(nextPrice4)
            .build();
    }

    private int nextRandomPrice(int aPrice4Ref, int aPenniesUpOrDown, int aPrice4Floor, int aPrice4Ceiling)
    {
        int nextPrice = aPrice4Ref + (100 * (theRandom.nextInt(2 * aPenniesUpOrDown + 1) - aPenniesUpOrDown));
        return Math.min(aPrice4Ceiling, Math.max(aPrice4Floor, nextPrice));
    }

    void stop()
    {
        log.info("stop()");

        // kill the timer()
        theTimer.cancel();
        theMDServer.close();
    }
}

package com.octillion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SettingsMDServer
{
    SettingsRabbitMQ SettingsRabbitMQ;
    String CvsFileMD;

    SettingsMDServer()
    {
        SettingsRabbitMQ = new SettingsRabbitMQ();
        CvsFileMD = "ClosingPrices.csv";
    }

    @Override
    public String toString()
    {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(this, SettingsMDServer.class);
    }

    static SettingsMDServer FromJson(String aFilename)
    {
        try
        {
            Gson gson = new Gson();
            JsonReader reader = new JsonReader(new FileReader(aFilename));
            return gson.fromJson(reader, SettingsMDServer.class);
        }
        catch (FileNotFoundException ex)
        {
            ex.printStackTrace();
            throw new RuntimeException(ex.getMessage());
        }
    }

    static void ToJson(SettingsMDServer aSettings, String aFilename)
    {
        try
        {
            Gson gson = new Gson();
            JsonWriter writer = new JsonWriter(new FileWriter(aFilename));
            writer.setIndent("  ");
            gson.toJson(aSettings, SettingsMDServer.class, writer);
            writer.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
            throw new RuntimeException(ex.getMessage());
        }
    }
}

package com.octillion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.Serializable;

public class SettingsRabbitMQ implements Serializable
{
    String Hostname;
    int Port;
    String UserName;
    String UserPass;
    String VirtualHost;
    String ExchangeDirect;
    String ExchangeFanout;
    String ExchangeTopic;
    String ExchangeHeader;

    public SettingsRabbitMQ()
    {
        Hostname = "localhost";
        Port = 5672;
        UserName = "guest";
        UserPass = "guest";
        VirtualHost = "/";
        ExchangeDirect = "amq.direct";
        ExchangeFanout = "amq.fanout";
        ExchangeTopic = "amq.topic";
        ExchangeHeader = "amq.header";
    }

    @Override
    public String toString()
    {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(this, SettingsRabbitMQ.class);
    }
}

#!/bin/bash

funcJarFolder() {
    local -r artifactName=$1
    echo ${artifactName}_jar
}

funcJarFile() {
    local -r artifactName=$1
    echo ${artifactName}.jar
}

funcJarPath() {
    local -r artifactName=$1
    echo "out\artifacts\\$(funcJarFolder ${artifactName})"
}

funcScpFile() {
    local -r srcPath=$1
    local -r srcFile=$2
    local -r userName=$3
    local -r destHost=$4
    local -r destDir=$5
    #echo scp "${srcPath}\\${srcFile}" "${userName}@${destHost}:${destDir}/${srcFile}"
    scp "${srcPath}\\${srcFile}" "${userName}@${destHost}:${destDir}/${srcFile}"
}

funcChmodExe() {
    local -r artifactName=$1
    local -r userName=$2
    local -r destHost=$3
    local -r destDir=$4
    #echo ssh "${userName}@${destHost}" chmod a+x "${destDir}/$(funcJarFile ${artifactName})"
    ssh "${userName}@${destHost}" chmod a+x "${destDir}/$(funcJarFile ${artifactName})"
}

funcDeployJar() {
    local -r artifactName=$1
    local -r userName=$2
    local -r destHost=$3
    local -r destDir=$4
    funcScpFile "$(funcJarPath ${artifactName})" "$(funcJarFile ${artifactName})" $userName $destHost $destDir
    funcChmodExe $artifactName $userName $destHost $destDir
}
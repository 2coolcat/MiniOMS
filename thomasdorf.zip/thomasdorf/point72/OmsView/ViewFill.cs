﻿using log4net;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Octillion.OmsView
{
    public partial class ViewFill : UserControl
    {
        static readonly ILog log = LogManager.GetLogger(typeof(ViewFill));

        private DataView theDataView;

        public ViewFill()
        {
            InitializeComponent();

            dataGridView.SetColumnWidths(new List<int>() { 76, 57, 72, 47, 49, 50 });
            dataGridView.Stylize(Color.Gold);
        }

        public void DumpColumnWidths(int margin)
        {
            log.Info(dataGridView.GetColumnWidthsAsList(margin));
        }

        /// <summary>
        /// Locks data and refreshes grid
        /// </summary>
        public void RefreshGrid()
        {
            lock (theOmsViewModel.OmsViewModelLock)
            {
                dataGridView.Refresh();
            }
        }

        public void SetFilter(string aBookName, string aTicker)
        {
            if (theDataView != null)
            {
                SelectDefaultRow();

                theDataView.RowFilter = string.Format("BookName = '{0}' AND Ticker = '{1}'",
                    aBookName,
                    aTicker);
            }
        }

        public void SelectDefaultRow()
        {
            if (theOmsViewModel != null)
            {
                lock (theOmsViewModel.OmsViewModelLock)
                {
                    dataGridView.SelectRowZero();
                }
            }
        }

        public OmsViewModel OmsViewModel
        {
            get { return theOmsViewModel; }
            set
            {
                theOmsViewModel = value;

                theDataView = (theOmsViewModel == null) ?
                    null :
                    new DataView(theOmsViewModel.Fill, "", "TimeStamp Asc", DataViewRowState.CurrentRows);

                dataGridView.DataSource = (theOmsViewModel == null) ?
                    null :
                    theDataView;

                dataGridView.SetColumnSortMode(DataGridViewColumnSortMode.NotSortable);
            }
        }
        OmsViewModel theOmsViewModel;
    }
}

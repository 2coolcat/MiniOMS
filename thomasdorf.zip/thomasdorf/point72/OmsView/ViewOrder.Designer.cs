﻿namespace Octillion.OmsView
{
    partial class ViewOrder
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView = new Octillion.OmsView.DataGridViewDB();
            this.label1 = new System.Windows.Forms.Label();
            this.selectionBanner = new Octillion.OmsView.SelectionBanner();
            this.bookNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tickerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeStampDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderBuyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toBuyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toSellDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderSellDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bookNameDataGridViewTextBoxColumn,
            this.tickerDataGridViewTextBoxColumn,
            this.iDDataGridViewTextBoxColumn,
            this.timeStampDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.orderBuyDataGridViewTextBoxColumn,
            this.toBuyDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.toSellDataGridViewTextBoxColumn,
            this.orderSellDataGridViewTextBoxColumn});
            this.dataGridView.AllowUserToResizeRows = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.Location = new System.Drawing.Point(0, 80);
            this.dataGridView.MultiSelect = false;
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.Size = new System.Drawing.Size(300, 213);
            this.dataGridView.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "Orders";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // selectionBanner
            // 
            this.selectionBanner.BackColor = System.Drawing.Color.Black;
            this.selectionBanner.Dock = System.Windows.Forms.DockStyle.Top;
            this.selectionBanner.Location = new System.Drawing.Point(0, 0);
            this.selectionBanner.Name = "selectionBanner";
            this.selectionBanner.Size = new System.Drawing.Size(300, 40);
            this.selectionBanner.TabIndex = 0;
            // 
            // bookNameDataGridViewTextBoxColumn
            // 
            this.bookNameDataGridViewTextBoxColumn.DataPropertyName = "BookName";
            this.bookNameDataGridViewTextBoxColumn.HeaderText = "Book";
            this.bookNameDataGridViewTextBoxColumn.Name = "bookNameDataGridViewTextBoxColumn";
            this.bookNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tickerDataGridViewTextBoxColumn
            // 
            this.tickerDataGridViewTextBoxColumn.DataPropertyName = "Ticker";
            this.tickerDataGridViewTextBoxColumn.HeaderText = "Ticker";
            this.tickerDataGridViewTextBoxColumn.Name = "tickerDataGridViewTextBoxColumn";
            this.tickerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "OrderID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // timeStampDataGridViewTextBoxColumn
            // 
            this.timeStampDataGridViewTextBoxColumn.DataPropertyName = "TimeStamp";
            this.timeStampDataGridViewTextBoxColumn.HeaderText = "TimeStamp";
            this.timeStampDataGridViewTextBoxColumn.Name = "timeStampDataGridViewTextBoxColumn";
            this.timeStampDataGridViewTextBoxColumn.DefaultCellStyle.Format = "HH:mm:ss";
            this.timeStampDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.timeStampDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // orderBuyDataGridViewTextBoxColumn
            // 
            this.orderBuyDataGridViewTextBoxColumn.DataPropertyName = "OrderBuy";
            this.orderBuyDataGridViewTextBoxColumn.HeaderText = "OrderBuy";
            this.orderBuyDataGridViewTextBoxColumn.Name = "OrderBuy";
            this.orderBuyDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#;(#,#);-";
            this.orderBuyDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.orderBuyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // toBuyDataGridViewTextBoxColumn
            // 
            this.toBuyDataGridViewTextBoxColumn.DataPropertyName = "ToBuy";
            this.toBuyDataGridViewTextBoxColumn.HeaderText = "ToBuy";
            this.toBuyDataGridViewTextBoxColumn.Name = "ToBuy";
            this.toBuyDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#;(#,#);-";
            this.toBuyDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.toBuyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "Price";
            this.priceDataGridViewTextBoxColumn.DefaultCellStyle.Format = "N2";
            this.priceDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.priceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // toSellDataGridViewTextBoxColumn
            // 
            this.toSellDataGridViewTextBoxColumn.DataPropertyName = "ToSell";
            this.toSellDataGridViewTextBoxColumn.HeaderText = "ToSell";
            this.toSellDataGridViewTextBoxColumn.Name = "ToSell";
            this.toSellDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#;(#,#);-";
            this.toSellDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.toSellDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // orderSellDataGridViewTextBoxColumn
            // 
            this.orderSellDataGridViewTextBoxColumn.DataPropertyName = "OrderSell";
            this.orderSellDataGridViewTextBoxColumn.HeaderText = "OrderSell";
            this.orderSellDataGridViewTextBoxColumn.Name = "OrderSell";
            this.orderSellDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#;(#,#);-";
            this.orderSellDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.orderSellDataGridViewTextBoxColumn.ReadOnly = true;

            // 
            // ViewOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.selectionBanner);
            this.Name = "ViewOrder";
            this.Size = new System.Drawing.Size(300, 300);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Octillion.OmsView.DataGridViewDB dataGridView;
        private Octillion.OmsView.SelectionBanner selectionBanner;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tickerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeStampDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderBuyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn toBuyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn toSellDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderSellDataGridViewTextBoxColumn;
    }
}

﻿using System.Windows.Forms;

namespace Octillion.OmsView
{
    public partial class SelectionBanner : UserControl
    {
        private delegate void UpdateTitleDelegate(string aBookName, string aTicker);

        public SelectionBanner()
        {
            InitializeComponent();
        }

        public void UpdateTitle(string aBookName, string aTicker)
        {
            if (labelTitle.InvokeRequired)
            {
                labelTitle.Invoke(new UpdateTitleDelegate(UpdateTitle), new object[] { aBookName, aTicker });
            }
            else
            {
                labelTitle.Text = string.Format("{0}  {1}", aBookName, aTicker);
            }
        }
    }
}

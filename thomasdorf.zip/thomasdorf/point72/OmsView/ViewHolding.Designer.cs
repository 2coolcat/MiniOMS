﻿namespace Octillion.OmsView
{
    partial class HoldingView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView = new Octillion.OmsView.DataGridViewDB();
            this.label1 = new System.Windows.Forms.Label();
            this.bookNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tickerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionSODDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionCurrentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceCurrentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceOpenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricePrevCloseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bookNameDataGridViewTextBoxColumn,
            this.tickerDataGridViewTextBoxColumn,
            this.positionSODDataGridViewTextBoxColumn,
            this.positionCurrentDataGridViewTextBoxColumn,
            this.priceCurrentDataGridViewTextBoxColumn,
            this.priceOpenDataGridViewTextBoxColumn,
            this.pricePrevCloseDataGridViewTextBoxColumn});
            this.dataGridView.AllowUserToResizeRows = false;
            this.dataGridView.DataMember = "Holding";
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.Location = new System.Drawing.Point(0, 27);
            this.dataGridView.MultiSelect = false;
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.Size = new System.Drawing.Size(300, 273);
            this.dataGridView.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 27);
            this.label1.TabIndex = 2;
            this.label1.Text = "Positions";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bookNameDataGridViewTextBoxColumn
            // 
            this.bookNameDataGridViewTextBoxColumn.DataPropertyName = "BookName";
            this.bookNameDataGridViewTextBoxColumn.HeaderText = "Book";
            this.bookNameDataGridViewTextBoxColumn.Name = "BookName";
            this.bookNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.bookNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // tickerDataGridViewTextBoxColumn
            // 
            this.tickerDataGridViewTextBoxColumn.DataPropertyName = "Ticker";
            this.tickerDataGridViewTextBoxColumn.HeaderText = "Ticker";
            this.tickerDataGridViewTextBoxColumn.Name = "Ticker";
            this.tickerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // positionSODDataGridViewTextBoxColumn
            // 
            this.positionSODDataGridViewTextBoxColumn.DataPropertyName = "PositionSOD";
            this.positionSODDataGridViewTextBoxColumn.HeaderText = "SOD";
            this.positionSODDataGridViewTextBoxColumn.Name = "PositionSOD";
            this.positionSODDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#;(#,#);-";
            this.positionSODDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.positionSODDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // positionCurrentDataGridViewTextBoxColumn
            // 
            this.positionCurrentDataGridViewTextBoxColumn.DataPropertyName = "PositionCurrent";
            this.positionCurrentDataGridViewTextBoxColumn.HeaderText = "Position";
            this.positionCurrentDataGridViewTextBoxColumn.Name = "PositionCurrent";
            this.positionCurrentDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#;(#,#);-";
            this.positionCurrentDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.positionCurrentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceCurrentDataGridViewTextBoxColumn
            // 
            this.priceCurrentDataGridViewTextBoxColumn.DataPropertyName = "PriceCurrent";
            this.priceCurrentDataGridViewTextBoxColumn.HeaderText = "Pr.Cur";
            this.priceCurrentDataGridViewTextBoxColumn.Name = "PriceCurrent";
            this.priceCurrentDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#.00;(#,#.00);-";
            this.priceCurrentDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.priceCurrentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // priceOpenDataGridViewTextBoxColumn
            // 
            this.priceOpenDataGridViewTextBoxColumn.DataPropertyName = "PriceOpen";
            this.priceOpenDataGridViewTextBoxColumn.HeaderText = "Pr.Opn";
            this.priceOpenDataGridViewTextBoxColumn.Name = "PriceOpen";
            this.priceOpenDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#.00;(#,#.00);-";
            this.priceOpenDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.priceOpenDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pricePrevCloseDataGridViewTextBoxColumn
            // 
            this.pricePrevCloseDataGridViewTextBoxColumn.DataPropertyName = "PricePrevClose";
            this.pricePrevCloseDataGridViewTextBoxColumn.HeaderText = "Pr.PrvCls";
            this.pricePrevCloseDataGridViewTextBoxColumn.Name = "PricePrevClose";
            this.pricePrevCloseDataGridViewTextBoxColumn.DefaultCellStyle.Format = "#,#.00;(#,#.00);-";
            this.pricePrevCloseDataGridViewTextBoxColumn.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.pricePrevCloseDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // HoldingView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.label1);
            this.Name = "HoldingView";
            this.Size = new System.Drawing.Size(300, 300);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridViewDB dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tickerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionSODDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionCurrentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceCurrentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceOpenDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricePrevCloseDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label1;
    }
}

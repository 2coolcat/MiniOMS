﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Octillion.OmsView
{
    /// <summary>
    /// A wrapper class to force double-buffering
    /// which removes flicker on Refresh()
    /// </summary>
    class DataGridViewDB : DataGridView
    {
        public DataGridViewDB()
        {
            DoubleBuffered = true;
        }
    }
}

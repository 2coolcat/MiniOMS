﻿using log4net;
using OmsModels;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octillion.OmsView
{
    class EventArgsModelSOD : EventArgs
    {
        public ModelSOD ModelSOD { get; private set; }

        public EventArgsModelSOD(ModelSOD modelSOD)
        {
            ModelSOD = modelSOD;
        }
    }

    class EventArgsModelOrder : EventArgs
    {
        public ModelOrder ModelOrder { get; private set; }

        public EventArgsModelOrder(ModelOrder modelOrder)
        {
            ModelOrder = modelOrder;
        }
    }

    class EventArgsModelFill : EventArgs
    {
        public ModelFill ModelFill { get; private set; }

        public EventArgsModelFill(ModelFill modelFill)
        {
            ModelFill = modelFill;
        }
    }

    class OmsClientRabbitMQ : IOmsClient
    {
        static readonly ILog log = LogManager.GetLogger(typeof(OmsClientRabbitMQ));

        // TODO These could come from shared json file
        static readonly string QUEUENAME_SOD = "OmsSod";
        static readonly string QUEUENAME_ORDERS = "OmsOrders";
        static readonly string QUEUENAME_FILLS = "OmsFills";

        public event EventHandler<EventArgsModelSOD> RecvModelSOD;
        public event EventHandler<EventArgsModelOrder> RecvModelOrder;
        public event EventHandler<EventArgsModelFill> RecvModelFill;

        readonly IModel theChannel;
        readonly IConnection theConnection;

        public OmsClientRabbitMQ(SettingsRabbitMQ aSettings)
        {
            ConnectionFactory factory = new ConnectionFactory()
            {
                HostName = aSettings.Hostname,
                Port = aSettings.Port,
                UserName = aSettings.UserName,
                Password = aSettings.UserPass,
                VirtualHost = aSettings.VirtualHost
            };

            theConnection = factory.CreateConnection();
            theChannel = theConnection.CreateModel();
        }

        /// <summary>
        /// Takes a queue name and creates a handler for that RabbitMQ queue.
        /// Starts the consume process as well
        /// </summary>
        /// <param name="aQueueName">A queue name. Ok if it already exists</param>
        /// <param name="handler">The handler to call on message arrival</param>
        void CreateHandler(string aQueueName, EventHandler<BasicDeliverEventArgs> handler)
        {
            theChannel.QueueDeclare(aQueueName, true, false, false, null);

            EventingBasicConsumer consumer = new EventingBasicConsumer(theChannel);
            consumer.Received += handler;
            theChannel.BasicConsume(aQueueName, true, consumer);
        }

        /// <summary>
        /// Creates and starts handlers for our 3 RabbitMQ queues.
        /// For our purposes the handler simply constructs a model 
        /// object from the received bytes and fires an event.
        /// </summary>
        public void StartSOD()
        {
            log.Info("StartSOD()");
            CreateHandler(QUEUENAME_SOD, (model, buf) => RecvModelSOD?.Invoke(this, new EventArgsModelSOD(ModelSOD.Parser.ParseFrom(buf.Body))));
        }

        public void StartOrders()
        {
            log.Info("StartOrders()");
            CreateHandler(QUEUENAME_ORDERS, (model, buf) => RecvModelOrder?.Invoke(this, new EventArgsModelOrder(ModelOrder.Parser.ParseFrom(buf.Body))));
        }

        public void StartFills()
        {
            log.Info("StartFills()");
            CreateHandler(QUEUENAME_FILLS, (model, buf) => RecvModelFill?.Invoke(this, new EventArgsModelFill(ModelFill.Parser.ParseFrom(buf.Body))));
        }

        public void Stop()
        {
            log.Info("Stop()");
            theConnection.Close();
            log.Info("theConnection.Close() DONE");
        }
    }
}

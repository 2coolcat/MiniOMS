﻿using System;

namespace Octillion.OmsView
{
    interface IMDClient
    {
        event EventHandler<EventArgsModelMarketData> RecvModelMarketData;
        void Subscribe(string aTicker);
        void Stop();
    }
}

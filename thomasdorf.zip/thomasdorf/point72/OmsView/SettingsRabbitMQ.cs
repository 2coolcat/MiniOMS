﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octillion.OmsView
{
    class SettingsRabbitMQ
    {
        public string Hostname { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string UserPass { get; set; }
        public string VirtualHost { get; set; }
        public string ExchangeDirect { get; set; }
        public string ExchangeFanout { get; set; }
        public string ExchangeTopic { get; set; }
        public string ExchangeHeader { get; set; }

        /// <summary>
        /// Set defaults
        /// </summary>
        public SettingsRabbitMQ()
        {
            Hostname = "localhost";
            Port = 5672;
            UserName = "guest";
            UserPass = "guest";
            VirtualHost = "/";
            ExchangeDirect = "amq.direct";
            ExchangeFanout = "amq.fanout";
            ExchangeTopic = "amq.topic";
            ExchangeHeader = "amq.header";
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

        public static SettingsRabbitMQ FromJsonFile(string aFilename)
        {
            return JsonConvert.DeserializeObject<SettingsRabbitMQ>(File.ReadAllText(aFilename));
        }

        public static void ToJsonFile(SettingsRabbitMQ aSettings, string aFilename)
        {
            File.WriteAllText(aFilename, JsonConvert.SerializeObject(aSettings, Formatting.Indented));
        }
    }
}

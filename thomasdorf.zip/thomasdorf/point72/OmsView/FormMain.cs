﻿using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Octillion.OmsView
{
    public partial class FormMain : Form
    {
        static readonly ILog log = LogManager.GetLogger(typeof(FormMain));
        static readonly string SETTINGS_FILE = "SettingsRabbitMQ.json";

        static readonly int GridRefreshIntervalMillis = 500;

        Timer TimerRefreshGridView;
        OmsEngine OmsEngine { get; set; }

        public FormMain()
        {
            InitializeComponent();
        }

        void OnFormMain_Load(object sender, EventArgs e)
        {
            // TODO add simple status event to handle connect to RabbitMQ
            SettingsRabbitMQ settingsRabbitMQ = SettingsRabbitMQ.FromJsonFile(SETTINGS_FILE);
            log.InfoFormat("{0}\n{1}", SETTINGS_FILE, settingsRabbitMQ.ToString());

            OmsEngine = new OmsEngine(
                new OmsClientRabbitMQ(settingsRabbitMQ),
                new MDClientRabbitMQ(settingsRabbitMQ));

            OmsEngine.SODCompleted += OnEngine_SODCompleted;

            theViewHolding.OmsViewModel = OmsEngine.OmsViewModel;
            theViewOrder.OmsViewModel = OmsEngine.OmsViewModel;
            theViewFill.OmsViewModel = OmsEngine.OmsViewModel;

            theViewHolding.SelectionChanged += OnHolding_SelectionChanged;

            InitTimerRefresh();

            OmsEngine.Start();
        }

        void OnMDClient_RecvModelMarketData(object sender, EventArgsModelMarketData e)
        {
            log.InfoFormat("OnMDClient_RecvModelMarketData {0}", e.ModelMarketData);
        }

        void OnEngine_SODCompleted(object sender, EventArgs e)
        {
            theViewHolding.SelectDefaultRow();
        }

        void OnHolding_SelectionChanged(object sender, EventArgsHoldingSelect e)
        {
            lock (OmsEngine.OmsViewModel.OmsViewModelLock)
            {
                theViewOrder.SetFilter(e.BookName, e.Ticker);
                theViewFill.SetFilter(e.BookName, e.Ticker);
                theViewOrder.UpdateTitle(e.BookName, e.Ticker);
            }
        }

        void InitTimerRefresh()
        {
            TimerRefreshGridView = new Timer();
            TimerRefreshGridView.Interval = GridRefreshIntervalMillis;
            TimerRefreshGridView.Tick += OnTimerRefreshGrid_Tick;
            TimerRefreshGridView.Start();
        }

        /// <summary>
        /// Refresh grid based on timer to avoid 
        /// bogging down UI to rapid data updates
        /// </summary>
        void OnTimerRefreshGrid_Tick(object sender, EventArgs e)
        {
            lock (OmsEngine.OmsViewModel.OmsViewModelLock)
            {
                OmsEngine.OmsViewModel.AcceptChangesSignal();
                theViewHolding.RefreshGrid();
                theViewOrder.RefreshGrid();
                theViewFill.RefreshGrid();
            }
        }

        void OnFormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            OmsEngine?.Stop();
        }

        void OnMenuClearAll_Click(object sender, EventArgs e)
        {
            OmsEngine.ClearData();
        }

        private void dumpColumnWidthsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            theViewHolding.DumpColumnWidths(1);
            theViewOrder.DumpColumnWidths(1);
            theViewFill.DumpColumnWidths(1);
        }
    }
}

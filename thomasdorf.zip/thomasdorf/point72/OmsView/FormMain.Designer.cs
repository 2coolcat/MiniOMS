﻿namespace Octillion.OmsView
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.label1 = new System.Windows.Forms.Label();
            this.panelTop = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.dumpColumnWidthsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.theViewOrder = new Octillion.OmsView.ViewOrder();
            this.theViewHolding = new Octillion.OmsView.HoldingView();
            this.theViewFill = new Octillion.OmsView.ViewFill();
            this.panelTop.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1084, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "FUSION (beta)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1084, 25);
            this.panelTop.TabIndex = 2;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuClearAll,
            this.dumpColumnWidthsToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(194, 48);
            // 
            // menuClearAll
            // 
            this.menuClearAll.Name = "menuClearAll";
            this.menuClearAll.Size = new System.Drawing.Size(193, 22);
            this.menuClearAll.Text = "Clear All Data";
            this.menuClearAll.Click += new System.EventHandler(this.OnMenuClearAll_Click);
            // 
            // dumpColumnWidthsToolStripMenuItem
            // 
            this.dumpColumnWidthsToolStripMenuItem.Name = "dumpColumnWidthsToolStripMenuItem";
            this.dumpColumnWidthsToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.dumpColumnWidthsToolStripMenuItem.Text = "Dump Column Widths";
            this.dumpColumnWidthsToolStripMenuItem.Click += new System.EventHandler(this.dumpColumnWidthsToolStripMenuItem_Click);
            // 
            // theViewOrder
            // 
            this.theViewOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.theViewOrder.Location = new System.Drawing.Point(0, 25);
            this.theViewOrder.Name = "theViewOrder";
            this.theViewOrder.OmsViewModel = null;
            this.theViewOrder.Size = new System.Drawing.Size(705, 472);
            this.theViewOrder.TabIndex = 3;
            // 
            // theViewHolding
            // 
            this.theViewHolding.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.theViewHolding.Location = new System.Drawing.Point(0, 497);
            this.theViewHolding.Name = "theViewHolding";
            this.theViewHolding.OmsViewModel = null;
            this.theViewHolding.Size = new System.Drawing.Size(705, 264);
            this.theViewHolding.TabIndex = 0;
            // 
            // theViewFill
            // 
            this.theViewFill.Dock = System.Windows.Forms.DockStyle.Right;
            this.theViewFill.Location = new System.Drawing.Point(705, 25);
            this.theViewFill.Name = "theViewFill";
            this.theViewFill.OmsViewModel = null;
            this.theViewFill.Size = new System.Drawing.Size(379, 736);
            this.theViewFill.TabIndex = 4;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1084, 761);
            this.Controls.Add(this.theViewOrder);
            this.Controls.Add(this.theViewHolding);
            this.Controls.Add(this.theViewFill);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnFormMain_FormClosing);
            this.Load += new System.EventHandler(this.OnFormMain_Load);
            this.panelTop.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private HoldingView theViewHolding;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelTop;
        private ViewOrder theViewOrder;
        private ViewFill theViewFill;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuClearAll;
        private System.Windows.Forms.ToolStripMenuItem dumpColumnWidthsToolStripMenuItem;
    }
}


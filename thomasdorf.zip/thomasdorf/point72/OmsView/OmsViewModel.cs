﻿using log4net;
using OmsModels;
using System;
using System.Linq;

namespace Octillion.OmsView
{
    partial class OmsViewModel
    {
        static readonly ILog log = LogManager.GetLogger(typeof(OmsViewModel));

        private static readonly decimal PRICE4_DIV = 10000M;
        private static readonly long EOF_MODELSOD_UTC = 0L;

        /// <summary>
        /// lock on this to ensure Refresh() and data 
        /// update operations do not interfere
        /// </summary>
        public object OmsViewModelLock { get; private set; }

        public OmsViewModel(object aLockObject) : this()
        {
            OmsViewModelLock = aLockObject;
            IsSelectionSuspended = false;
        }

        public bool IsSelectionSuspended { get; private set; }

        /// <summary>
        /// AcceptChages() can cause instantaneous changes in the
        /// selected row, so we suspend until all rows are selected
        /// </summary>
        public void AcceptChangesSignal()
        {
            IsSelectionSuspended = true;
            AcceptChanges();
            IsSelectionSuspended = false;
        }

        /// <summary>
        /// Create a new HoldingRow for received ModelSODs
        /// </summary>
        /// <param name="modelSOD"></param>
        /// <returns>Returns true when received the End-Of-Feed ModelSOD</returns>
        internal bool ProcessModelSOD(ModelSOD modelSOD)
        {
            bool isEndOfFeed = (modelSOD.BusDateUTC == EOF_MODELSOD_UTC);

            if (!isEndOfFeed)
            {
                lock (OmsViewModelLock)
                {
                    Holding.AddHoldingRow(modelSOD);
                }
            }

            return isEndOfFeed;
        }

        internal void ProcessModelOrder(ModelOrder modelOrder)
        {
            lock (OmsViewModelLock)
            {
                Order.ProcessModelOrder(modelOrder);
            }
        }

        internal void ProcessModelMarketData(ModelMarketData modelMarketData)
        {
            lock (OmsViewModelLock)
            {
                IsSelectionSuspended = true;
                Holding.ProcessModelMarketData(modelMarketData);
                IsSelectionSuspended = false;
            }
        }

        internal void ProcessModelFill(ModelFill modelFill)
        {
            lock (OmsViewModelLock)
            {
                Fill.ProcessModelFill(modelFill);
                Holding.ProcessModelFill(modelFill);
            }
        }

        partial class HoldingDataTable
        {
            internal void AddHoldingRow(ModelSOD modelSOD)
            {
                DateTime busDate = Extensions.LocalTimeFromUTCSeconds(modelSOD.BusDateUTC);
                log.DebugFormat("ModelSOD.BusDateUTC as Local DateTime = {0}", busDate.ToString("yyyyMMdd HH:mm:ss"));

                // TODO Check that the date is today
                try
                {
                    AddHoldingRow(
                        modelSOD.BookName,
                        modelSOD.Ticker,
                        modelSOD.PositionBook,
                        modelSOD.PositionBook,
                        0M,
                        0M,
                        0M);
                }
                catch (Exception ex)
                {
                    log.ErrorFormat("REJECTED: Duplicate SOD received: {0}, {1}", modelSOD, ex.Message);
                }
            }

            internal void ProcessModelFill(ModelFill modelFill)
            {
                FindByBookNameTicker(modelFill.BookName, modelFill.Ticker).PositionCurrent = modelFill.PositionBook;
            }

            internal void ProcessModelMarketData(ModelMarketData modelMarketData)
            {
                // update all rows with matching Ticker
                foreach(var row in Rows.Cast<HoldingRow>().Where(r => r.Ticker == modelMarketData.Ticker))
                {
                    row.PriceCurrent = modelMarketData.Price4Current / PRICE4_DIV;
                    row.PriceOpen = modelMarketData.Price4Open / PRICE4_DIV;
                    row.PricePrevClose = modelMarketData.Price4PrevClose / PRICE4_DIV;
                }
            }
        }

        partial class OrderDataTable
        {
            internal void ProcessModelOrder(ModelOrder modelOrder)
            {
                log.DebugFormat("DateTime.Now.ToUnixTimeSeconds() = {0}", new DateTimeOffset(DateTime.Now).ToUnixTimeSeconds());
                log.DebugFormat("modelOrder.TradeDateUTC = {0}", modelOrder.TradeDateUTC);
                log.DebugFormat("TOD = {0}", modelOrder.TradeDateUTC % (3600 * 24));

                try
                {
                    OrderRow orderRow = FindByID(modelOrder.OrderId);

                    if (orderRow != null)
                    {
                        RemoveOrderRow(orderRow);
                    }

                    AddOrderRow(
                        modelOrder.BookName,
                        modelOrder.Ticker,
                        modelOrder.OrderId,
                        Extensions.LocalTimeFromUTCSeconds(modelOrder.TradeDateUTC),
                        modelOrder.Side.ToString(),
                        modelOrder.Action.ToString(),
                        (modelOrder.Side == ModelOrder.Types.EnumSide.Buy) ? modelOrder.SharesOrder : 0,
                        (modelOrder.Side == ModelOrder.Types.EnumSide.Buy) ? modelOrder.SharesToGo : 0,
                        (modelOrder.Price4 / PRICE4_DIV),
                        (modelOrder.Side == ModelOrder.Types.EnumSide.Sell) ? modelOrder.SharesToGo : 0,
                        (modelOrder.Side == ModelOrder.Types.EnumSide.Sell) ? modelOrder.SharesOrder : 0);
                }
                catch (Exception ex)
                {
                    log.ErrorFormat("REJECTED: Order {0}, {1}", modelOrder, ex.Message);
                }
            }
        }

        partial class FillDataTable
        {
            internal void ProcessModelFill(ModelFill modelFill)
            {
                try
                {
                    AddFillRow(
                        Extensions.LocalTimeFromUTCSeconds(modelFill.TradeDateUTC),
                        modelFill.OrderId,
                        modelFill.BookName,
                        modelFill.Ticker,
                        (DataSet as OmsViewModel).Order.FindByID(modelFill.OrderId).Side,
                        modelFill.SharesFilled);
                }
                catch (Exception ex)
                {
                    log.ErrorFormat("REJECTED: Fill {0}, {1}", modelFill, ex.Message);
                }
            }
        }
    }
}

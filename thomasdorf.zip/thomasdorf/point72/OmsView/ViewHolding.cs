﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using log4net;

namespace Octillion.OmsView
{
    partial class HoldingView : UserControl
    {
        static readonly ILog log = LogManager.GetLogger(typeof(HoldingView));

        private DataView theDataView;
        public event EventHandler<EventArgsHoldingSelect> SelectionChanged;

        public HoldingView()
        {
            InitializeComponent();

            dataGridView.SetColumnWidths(new List<int>() { 60, 67, 59, 76, 66, 71, 79 });
            dataGridView.Stylize(Color.Gold);
            dataGridView.SelectionChanged += OnSelectionChanged;
        }

        public void DumpColumnWidths(int margin)
        {
            log.Info(dataGridView.GetColumnWidthsAsList(margin));
        }

        public void SelectDefaultRow()
        {
            if (theOmsViewModel != null)
            {
                lock (theOmsViewModel.OmsViewModelLock)
                {
                    dataGridView.SelectRowZero();
                }
            }
        }

        /// <summary>
        /// When selection on the Holding grid changes we
        /// will update filters on other grids appropriately
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void OnSelectionChanged(object sender, EventArgs e)
        {
            if (!theOmsViewModel.IsSelectionSuspended &&
                (dataGridView.SelectedRows.Count > 0))
            {
                SelectionChanged?.Invoke(this, new EventArgsHoldingSelect(
                     dataGridView.SelectedRows[0].Cells["BookName"].Value.ToString(),
                     dataGridView.SelectedRows[0].Cells["Ticker"].Value.ToString()));
            }
        }

        /// <summary>
        /// Locks data and refreshes grid
        /// </summary>
        public void RefreshGrid()
        {
            lock (theOmsViewModel.OmsViewModelLock)
            {
                dataGridView.Refresh();
            }
        }

        public OmsViewModel OmsViewModel
        {
            get { return theOmsViewModel; }
            set
            {
                theOmsViewModel = value;

                theDataView = (theOmsViewModel == null) ?
                    null :
                    new DataView(theOmsViewModel.Holding, "", "BookName Asc", DataViewRowState.CurrentRows);

                dataGridView.DataSource = (theOmsViewModel == null) ?
                    null :
                    theDataView;

                dataGridView.SetColumnSortMode(DataGridViewColumnSortMode.NotSortable);
            }
        }
        OmsViewModel theOmsViewModel;
    }

    class EventArgsHoldingSelect : EventArgs
    {
        public string BookName { get; private set; }
        public string Ticker { get; private set; }

        public EventArgsHoldingSelect(string bookName, string ticker)
        {
            BookName = bookName;
            Ticker = ticker;
        }
    }
}

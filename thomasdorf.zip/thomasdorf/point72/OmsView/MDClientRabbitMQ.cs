﻿using log4net;
using OmsModels;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octillion.OmsView
{
    class EventArgsModelMarketData : EventArgs
    {
        public ModelMarketData ModelMarketData { get; private set; }

        public EventArgsModelMarketData(ModelMarketData modelMarketData)
        {
            ModelMarketData = modelMarketData;
        }
    }

    class MDClientRabbitMQ : IMDClient
    {
        static readonly ILog log = LogManager.GetLogger(typeof(MDClientRabbitMQ));

        public event EventHandler<EventArgsModelMarketData> RecvModelMarketData;

        readonly IModel theChannel;
        readonly IConnection theConnection;
        readonly string theQueueName;

        public MDClientRabbitMQ(SettingsRabbitMQ aSettings)
        {
            ConnectionFactory factory = new ConnectionFactory()
            {
                HostName = aSettings.Hostname,
                Port = aSettings.Port,
                UserName = aSettings.UserName,
                Password = aSettings.UserPass,
                VirtualHost = aSettings.VirtualHost
            };

            theConnection = factory.CreateConnection();
            theChannel = theConnection.CreateModel();

            // Creates auto-named, non-durable, exclusive, auto-delete Queue
            theQueueName = theChannel.QueueDeclare().QueueName;

            log.InfoFormat("Created Queue {0}", theQueueName);

            EventingBasicConsumer consumer = new EventingBasicConsumer(theChannel);
            consumer.Received += (model, buf) => RecvModelMarketData?.Invoke(
                this, 
                new EventArgsModelMarketData(ModelMarketData.Parser.ParseFrom(buf.Body)));

            theChannel.BasicConsume(theQueueName, true, consumer);
        }

        /// <summary>
        /// Binds a RoutingKey/TopicFilter to our Queue
        /// Careful to replace period characters from tickers
        /// </summary>
        public void Subscribe(string aTicker)
        {
            log.InfoFormat("Subscribe to {0}", aTicker);
            theChannel.QueueBind(theQueueName, "amq.topic", TopicFromTicker(aTicker), null);
        }

        /// <summary>
        /// Topics have defined function for '.' replace with '_'
        /// </summary>
        /// <param name="aTicker">A Ticker with embedded '.'</param>
        /// <returns>Returns a Ticker with '_' in place of '.'</returns>
        static string TopicFromTicker(string aTicker)
        {
            return aTicker.Replace('.', '_');
        }

        public void Stop()
        {
            log.Info("Stop()");
            theConnection.Close();
            log.Info("theConnection.Close() DONE");
        }
    }
}

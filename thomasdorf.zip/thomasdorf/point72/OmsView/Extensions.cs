﻿using OmsModels;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Octillion.OmsView
{
    static class Extensions
    {
        public static bool IsBuy(this ModelOrder.Types.EnumAction enumAction)
        {
            return
                (enumAction == ModelOrder.Types.EnumAction.Buycover) ||
                (enumAction == ModelOrder.Types.EnumAction.Buylong);
        }

        public static bool IsSell(this ModelOrder.Types.EnumAction enumAction)
        {
            return
                (enumAction == ModelOrder.Types.EnumAction.Selllong) ||
                (enumAction == ModelOrder.Types.EnumAction.Sellshort);
        }

        public static DateTime DateTimeUTCEpoch = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);

        public static DateTime LocalTimeFromUTCMillis(long utcMillis)
        {
            return DateTimeUTCEpoch.AddMilliseconds(utcMillis).ToLocalTime();
        }

        public static DateTime LocalTimeFromUTCSeconds(long utcSeconds)
        {
            return DateTimeUTCEpoch.AddSeconds(utcSeconds).ToLocalTime();
        }

        public static void SetColumnSortMode(this DataGridView dataGridView, DataGridViewColumnSortMode sortMode)
        {
            dataGridView.Columns
                .Cast<DataGridViewColumn>()
                .ToList()
                .ForEach(f => f.SortMode = sortMode);
        }

        public static void ScrollToBottom(this DataGridView dgv)
        {
            if (dgv.RowCount > 0)
            {
                dgv.FirstDisplayedScrollingRowIndex = Math.Max(0, dgv.RowCount - dgv.DisplayedRowCount(false));
            }
        }

        public static void SelectRowZero(this DataGridView dataGridView)
        {
            if (dataGridView.Rows.Count > 0)
            {
                dataGridView.Rows[0].Selected = true;
            }
        }

        public static string GetColumnWidthsAsList(this DataGridView dataGridView, int margin)
        {
            return string.Format(
                "dataGridView.SetColumnWidths(new List<int>(){{{0}}});", 
                string.Join(", ", dataGridView.GetColumnWidths(margin)));
        }

        public static List<int> GetColumnWidths(this DataGridView dataGridView, int margin)
        {
            List<int> widths = new List<int>();
            foreach (DataGridViewColumn col in dataGridView.Columns)
            {
                widths.Add(col.Width + margin);
            }
            return widths;
        }

        public static void SetColumnWidths(this DataGridView dataGridView, List<int> columnWidths)
        {
            int index = 0;
            columnWidths.ForEach(w => dataGridView.Columns[index++].Width = w);
        }

        public static void Stylize(this DataGridView dataGridView, Color colorForeground)
        {
            dataGridView.ShowCellToolTips = false;
            dataGridView.BackgroundColor = Color.Black;
            dataGridView.RowTemplate.Height = 18;

            dataGridView.DefaultCellStyle.Font = new Font("Tahoma", 8);
            dataGridView.DefaultCellStyle.BackColor = Color.Black;
            dataGridView.DefaultCellStyle.ForeColor = colorForeground;
            dataGridView.DefaultCellStyle.SelectionBackColor = Color.Navy;
            dataGridView.DefaultCellStyle.SelectionForeColor = Color.Aqua;

            dataGridView.RowsDefaultCellStyle.BackColor = Color.Black;
            dataGridView.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(25, 25, 25);

            dataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 8);
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.WhiteSmoke;

            dataGridView.EnableHeadersVisualStyles = false;
        }
    }
}

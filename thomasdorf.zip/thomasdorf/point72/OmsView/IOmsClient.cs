﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Octillion.OmsView
{
    interface IOmsClient
    {
        event EventHandler<EventArgsModelSOD> RecvModelSOD;
        event EventHandler<EventArgsModelOrder> RecvModelOrder;
        event EventHandler<EventArgsModelFill> RecvModelFill;
        void StartSOD();
        void StartOrders();
        void StartFills();
        void Stop();
    }
}

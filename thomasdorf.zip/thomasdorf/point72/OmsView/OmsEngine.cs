﻿using log4net;
using System;

namespace Octillion.OmsView
{
    class OmsEngine
    {
        static readonly ILog log = LogManager.GetLogger(typeof(OmsEngine));

        IOmsClient OmsClient { get; set; }
        IMDClient MDClient { get; set; }

        public OmsViewModel OmsViewModel { get; private set; }

        public event EventHandler SODCompleted;

        public OmsEngine(
            IOmsClient omsClient,
            IMDClient mdClient)
        {
            OmsClient = omsClient;
            MDClient = mdClient;
            OmsViewModel = new OmsViewModel(new object());
        }

        public void Start()
        {
            log.Info("Start()");

            MDClient.RecvModelMarketData += OnRecvModelMarketData;

            OmsClient.RecvModelSOD += OnRecvModelSOD;
            OmsClient.RecvModelOrder += OnRecvModelOrder;
            OmsClient.RecvModelFill += OnRecvModelFill;
            OmsClient.StartSOD();
        }

        void OnRecvModelMarketData(object sender, EventArgsModelMarketData e)
        {
            OmsViewModel.ProcessModelMarketData(e.ModelMarketData);
        }

        public void Stop()
        {
            log.Info("Stop()");

            OmsClient?.Stop();
            MDClient?.Stop();
        }

        void OnRecvModelFill(object sender, EventArgsModelFill e)
        {
            log.Debug(e.ModelFill.ToString());
            OmsViewModel.ProcessModelFill(e.ModelFill);
        }

        void OnRecvModelOrder(object sender, EventArgsModelOrder e)
        {
            log.Debug(e.ModelOrder.ToString());
            OmsViewModel.ProcessModelOrder(e.ModelOrder);
        }

        void OnRecvModelSOD(object sender, EventArgsModelSOD e)
        {
            log.Debug(e.ModelSOD.ToString());

            bool isEndOfFeed = OmsViewModel.ProcessModelSOD(e.ModelSOD);

            // Wait for the end of SOD holding before processing Orders and Fills
            if (isEndOfFeed)
            {
                SODCompleted?.Invoke(this, EventArgs.Empty);

                OmsClient.StartOrders();
                OmsClient.StartFills();
            }
            else
            {
                MDClient?.Subscribe(e.ModelSOD.Ticker);
            }
        }

        internal void ClearData()
        {
            lock (OmsViewModel.OmsViewModelLock)
            {
                OmsViewModel.Clear();
            }
        }
    }
}

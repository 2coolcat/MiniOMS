﻿using log4net;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Octillion.OmsView
{
    public partial class ViewOrder : UserControl
    {
        static readonly ILog log = LogManager.GetLogger(typeof(ViewOrder));

        private DataView theDataView;

        public ViewOrder()
        {
            InitializeComponent();

            dataGridView.SetColumnWidths(new List<int>() { 60, 67, 57, 76, 61, 63, 63, 63, 63, 63 });
            dataGridView.Stylize(Color.Gold);
        }

        public void DumpColumnWidths(int margin)
        {
            log.Info(dataGridView.GetColumnWidthsAsList(margin));
        }

        public void UpdateTitle(string aBookName, string aTicker)
        {
            selectionBanner.UpdateTitle(aBookName, aTicker);
        }

        /// <summary>
        /// Locks data and refreshes grid
        /// </summary>
        public void RefreshGrid()
        {
            lock (theOmsViewModel.OmsViewModelLock)
            {
                dataGridView.Refresh();
            }
        }

        public void SetFilter(string aBookName, string aTicker)
        {
            if (theDataView != null)
            {
                string filter = string.Format("BookName = '{0}' AND Ticker = '{1}'",
                    aBookName,
                    aTicker);

                if (!filter.Equals(theDataView.RowFilter))
                {
                    SelectDefaultRow();
                    log.DebugFormat("theDataView.RowFilter = {0}, filter = {1}", theDataView.RowFilter, filter);
                    theDataView.RowFilter = filter;
                }
            }
        }

        public void SelectDefaultRow()
        {
            if (theOmsViewModel != null)
            {
                lock (theOmsViewModel.OmsViewModelLock)
                {
                    dataGridView.SelectRowZero();
                }
            }
        }

        public OmsViewModel OmsViewModel
        {
            get { return theOmsViewModel; }
            set
            {
                theOmsViewModel = value;

                theDataView = (theOmsViewModel == null) ?
                    null :
                    new DataView(theOmsViewModel.Order, "", "Price Desc", DataViewRowState.CurrentRows);

                dataGridView.DataSource = (theOmsViewModel == null) ?
                    null :
                    theDataView;

                dataGridView.SetColumnSortMode(DataGridViewColumnSortMode.NotSortable);
            }
        }
        OmsViewModel theOmsViewModel;
    }
}

package com.octillion;

import com.octillion.OmsModels.ModelFill;
import com.octillion.OmsModels.ModelOrder;
import org.jetbrains.annotations.NotNull;

class OmsModelFactory
{
    /**
     * Builds a ModelOrder with action = UNDEF_ACTION
     *
     * @param aLocalDateTimeString A DateTime string formatted like DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss"
     * @param anOrderId            The OrderId
     * @param aBookName            The Book Name
     * @param aTicker              The Ticker
     * @param aShares              The Shares, will fill in sharesOrder and sharesToGo
     * @param aPrice4              The price * 10,000
     * @return Returns a ModelOrder with action = UNDEF_ACTION, side=UNDEF_SIDE
     */
    @NotNull
    static ModelOrder ModelOrderBaseBuild(
        @NotNull String aLocalDateTimeString,
        int anOrderId,
        @NotNull String aBookName,
        @NotNull String aTicker,
        int aShares,
        int aPrice4)
    {
        return ModelOrder.newBuilder()
            .setTradeDateUTC(CsvUtils.parseDateTimeToEpochSeconds(aLocalDateTimeString))
            .setOrderId(anOrderId)
            .setBookName(aBookName)
            .setTicker(aTicker)
            .setAction(ModelOrder.EnumAction.UNDEF_ACTION)
            .setSide(ModelOrder.EnumSide.UNDEF_SIDE)
            .setSharesOrder(aShares)
            .setSharesToGo(aShares)
            .setPrice4(aPrice4)
            .build();
    }

    /**
     * Builds a ModelFill with positionBook = 0,
     * to be set later
     *
     * @param aLocalDateTimeString A DateTime string formatted like DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss"
     * @param anOrderId            The OrderId
     * @param aBookName            The Book Name
     * @param aTicker              The Ticker
     * @param aSharesFilled        Number of shares filled on the order
     * @return Returns a ModelFill with positionBook = 0
     */
    @NotNull
    static ModelFill ModelFillBaseBuild(
        @NotNull String aLocalDateTimeString,
        int anOrderId,
        @NotNull String aBookName,
        @NotNull String aTicker,
        int aSharesFilled)
    {
        return ModelFill.newBuilder()
            .setTradeDateUTC(CsvUtils.parseDateTimeToEpochSeconds(aLocalDateTimeString))
            .setOrderId(anOrderId)
            .setBookName(aBookName)
            .setTicker(aTicker)
            .setSharesFilled(aSharesFilled)
            .setPositionBook(0)
            .build();
    }

    static int positionDeltaFromOrder(@NotNull ModelOrder aModelOrder, int aShares)
    {
        int positionDelta = 0;

        if (aModelOrder.getSide() == ModelOrder.EnumSide.BUY)
        {
            positionDelta = aShares;
        }
        else if (aModelOrder.getSide() == ModelOrder.EnumSide.SELL)
        {
            positionDelta = -aShares;
        }

        return positionDelta;
    }

    @NotNull
    static ModelOrder.EnumSide enumSideFromString(@NotNull String aSide)
    {
        return
            aSide.trim().toLowerCase().startsWith("b") ?
                ModelOrder.EnumSide.BUY :
                aSide.trim().toLowerCase().startsWith("s") ?
                    ModelOrder.EnumSide.SELL :
                    ModelOrder.EnumSide.UNDEF_SIDE;
    }
}

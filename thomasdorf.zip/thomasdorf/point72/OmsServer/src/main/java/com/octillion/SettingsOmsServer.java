package com.octillion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SettingsOmsServer
{
    SettingsRabbitMQ SettingsRabbitMQ;
    String CvsFileSOD;
    String CvsFileOrders;
    String CvsFileFills;
    int EngineUpdatePeriodMillis;

    SettingsOmsServer()
    {
        SettingsRabbitMQ = new SettingsRabbitMQ();
        CvsFileSOD = "gen.SOD.csv";
        CvsFileOrders = "gen.Orders.csv";
        CvsFileFills = "gen.Fills.csv";
        EngineUpdatePeriodMillis = 1000;
    }

    @Override
    public String toString()
    {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(this, SettingsOmsServer.class);
    }

    static SettingsOmsServer FromJson(String aFilename)
    {
        try
        {
            Gson gson = new Gson();
            JsonReader reader = new JsonReader(new FileReader(aFilename));
            return gson.fromJson(reader, SettingsOmsServer.class);
        }
        catch (FileNotFoundException ex)
        {
            ex.printStackTrace();
            throw new RuntimeException(ex.getMessage());
        }
    }

    static void ToJson(SettingsOmsServer aSettings, String aFilename)
    {
        try
        {
            Gson gson = new Gson();
            JsonWriter writer = new JsonWriter(new FileWriter(aFilename));
            writer.setIndent("  ");
            gson.toJson(aSettings, SettingsOmsServer.class, writer);
            writer.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
            throw new RuntimeException(ex.getMessage());
        }
    }
}

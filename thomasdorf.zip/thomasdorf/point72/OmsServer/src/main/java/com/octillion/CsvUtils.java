package com.octillion;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

class CsvUtils
{
    private static Logger log = LoggerFactory.getLogger(CsvUtils.class);

    private static String DATE_FORMAT = "yyyy-MM-dd";
    private static String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    private static SimpleDateFormat CSV_DATE_FORMAT = new SimpleDateFormat(DATE_FORMAT);
    private static DateTimeFormatter CSV_DATE_TIME_FORMAT = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);

    static String[] ITEMS_DUMMY = new String[]{"dummy"};

    static long parseDateToEpochSeconds(@NotNull String aDateString)
    {
        Date date;
        try
        {
            date = CSV_DATE_FORMAT.parse(aDateString.trim());
        }
        catch(ParseException ex)
        {
            log.error("Poorly formatted Date string {}. Expecting {}.\n{}",
                aDateString,
                DATE_FORMAT,
                ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }

        return date.toInstant().atZone(ZoneId.systemDefault()).toEpochSecond();
    }

    static long parseDateTimeToEpochSeconds(@NotNull String aDateTimeString)
    {
        LocalDateTime dateTime;
        try
        {
            dateTime = LocalDateTime.parse(aDateTimeString.trim(), CSV_DATE_TIME_FORMAT);
        }
        catch(DateTimeParseException ex)
        {
            log.error("Poorly formatted DateTime string {}. Expecting {}.\n{}",
                aDateTimeString,
                DATE_TIME_FORMAT,
                ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }

        return dateTime.atZone(ZoneId.systemDefault()).toEpochSecond();
    }

    /**
     * Price format of CSV is decimal string (i.e. '123.45')
     * Price format of protobuf price4 fields is int32 (i.e. 1234500)
     * @param aPriceDecimal Price format of CSV is decimal string (i.e. '123.45')
     * @return Returns price4 format of protobuf int32 (i.e. 1234500)
     */
    static int parsePrice4(@NotNull String aPriceDecimal)
    {
        return (int) (Double.parseDouble(aPriceDecimal.trim()) * 10000.0);
    }
}

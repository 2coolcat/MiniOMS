package com.octillion;

import com.octillion.OmsModels.ModelOrder;
import com.octillion.OmsModels.ModelSOD;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class OmsServerEngine
{
    private static Logger log = LoggerFactory.getLogger(OmsServerEngine.class);

    private final IFeedSOD theFeedSOD;
    private final IFeedOrder theFeedOrder;
    private final IFeedFill theFeedFill;
    private final IOmsServer theOmsServer;

    private Map<String, BookState> theStateByBook;

    private ModelOrderCsv theModelOrderCsvNext = null;
    private ModelFillCsv theModelFillCsvNext = null;

    private Timer theTimer = new Timer();
    private volatile boolean theIsDone = false;
    private final Object theLockIsDone = new Object();
    private int thePeriodUpdateMillis;

    private void setDone(boolean aDone)
    {
        synchronized (theLockIsDone)
        {
            theIsDone = aDone;
        }
    }

    private boolean isDone()
    {
        synchronized (theLockIsDone)
        {
            return theIsDone;
        }
    }

    public OmsServerEngine(
        @NotNull IFeedSOD aFeedSOD,
        @NotNull IFeedOrder aFeedOrder,
        @NotNull IFeedFill aFeedFill,
        @NotNull IOmsServer aOmsServer,
        int aPeriodUpdateMillis)
    {
        theFeedSOD = aFeedSOD;
        theFeedOrder = aFeedOrder;
        theFeedFill = aFeedFill;
        theOmsServer = aOmsServer;
        thePeriodUpdateMillis = aPeriodUpdateMillis;

        theStateByBook = new HashMap<>();
    }

    @NotNull
    private BookState getOrCreateBookState(@NotNull String aBookName)
    {
        return theStateByBook.computeIfAbsent(aBookName, BookState::new);
    }

    void start()
    {
        setDone(false);

        // Send SOD messages and create bookstates and tickerstates
        theFeedSOD.runFeed(theOmsServer::sendSOD, this::createTickerState);

        // start process to feed Orders and Fills
        theTimer.scheduleAtFixedRate(
            new TimerTask()
            {
                @Override
                public void run()
                {
                    if (theModelOrderCsvNext == null)
                    {
                        theModelOrderCsvNext = theFeedOrder.nextOrder();
                    }

                    if (theModelFillCsvNext == null)
                    {
                        theModelFillCsvNext = theFeedFill.nextFill();
                    }

                    if (theModelOrderCsvNext.isEOF() && theModelFillCsvNext.isEOF())
                    {
                        log.info("Finished with Orders and Fills csv files");
                        stop();
                    }
                    else if (
                        theModelFillCsvNext.getModelFill().getTradeDateUTC() <
                        theModelOrderCsvNext.getModelOrder().getTradeDateUTC())
                    {
                        processModelFillMod(theModelFillCsvNext);
                        theModelFillCsvNext = null;
                    }
                    else
                    {
                        processModelOrderMod(theModelOrderCsvNext);
                        theModelOrderCsvNext = null;
                    }
                }
            },
            thePeriodUpdateMillis,
            thePeriodUpdateMillis);

            // Output All BookStates
    }

    /**
     * Create the state variables for each Book:Ticker pair
     * @param aModelSOD The ModelSOD derived from the csv
     */
    private void createTickerState(@NotNull ModelSOD aModelSOD)
    {
        BookState bookState = getOrCreateBookState(aModelSOD.getBookName());
        TickerState tickerState = bookState.getOrCreateTickerState(aModelSOD.getTicker());
        tickerState.setPosition(aModelSOD.getPositionBook());
    }

    /**
     * Use the TickerState to update action
     * @param aModelOrderCsv The incomplete ModelOrder, still needs action
     */
    private void processModelOrderMod(@NotNull ModelOrderCsv aModelOrderCsv)
    {
        ModelOrder modelOrder = null;

        TickerState tickerState = getTickerState(
            aModelOrderCsv.getModelOrder().getBookName(),
            aModelOrderCsv.getModelOrder().getTicker());

        if (tickerState == null)
        {
            log.error("REJECTED Order {}", aModelOrderCsv.getModelOrder());
        }
        else
        {
            modelOrder = tickerState.processOrderCsv(aModelOrderCsv);
        }

        if (modelOrder != null)
        {
            log.info("Sending Order {}", modelOrder);
            theOmsServer.sendOrder(modelOrder);
        }
    }

    private void processModelFillMod(@NotNull ModelFillCsv aModelFillCsv)
    {
        OmsModels.ModelFill modelFill = null;

        TickerState tickerState = getTickerState(
            aModelFillCsv.getModelFill().getBookName(),
            aModelFillCsv.getModelFill().getTicker());

        if (tickerState == null)
        {
            log.error("REJECTED Fill {}", aModelFillCsv.getModelFill());
        }
        else
        {
            modelFill = tickerState.processFillCsv(aModelFillCsv);
        }

        if (modelFill != null)
        {
            log.info("Sending Fill {}", modelFill);
            theOmsServer.sendFill(modelFill);

            ModelOrder modelOrder = tickerState.getOrdersById().get(modelFill.getOrderId());
            log.info("Sending Order {}", modelOrder);
            theOmsServer.sendOrder(modelOrder);
        }
    }

    @Nullable
    private TickerState getTickerState(@NotNull String aBookName, @NotNull String aTicker)
    {
        TickerState tickerState = null;

        BookState bookState = theStateByBook.getOrDefault(aBookName, null);

        if (bookState == null)
        {
            log.error("Unexpected BookName {}", aBookName);
        }
        else
        {
            tickerState = bookState.getTickerState(aTicker);

            if (tickerState == null)
            {
                log.error("Unexpected Ticker {}", aTicker);
            }
        }

        return tickerState;
    }

    void waitToFinish()
    {
        while(!isDone())
        {
            try
            {
                Thread.sleep(2000);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
    }

    private void stop()
    {
        log.info("stop()");

        theTimer.cancel();
        theOmsServer.close();

        setDone(true);
    }
}

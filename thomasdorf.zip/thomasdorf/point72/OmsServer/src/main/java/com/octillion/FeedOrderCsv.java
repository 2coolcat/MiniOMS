package com.octillion;

import com.octillion.OmsModels.ModelOrder;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

public class FeedOrderCsv implements IFeedOrder
{
    private static Logger log = LoggerFactory.getLogger(FeedOrderCsv.class);

    private static int ITEMS_PER_LINE = 8;
    /**
     * tradeDateUTC
     */
    private static String FIRST_HEADER = ModelOrder.getDescriptor().getFields().get(0).getName();
    private static String CSV_COMMENT = "#";

    private BufferedReader theBufferedReader;

    public FeedOrderCsv(@NotNull String aFilename)
    {
        try
        {
            theBufferedReader = new BufferedReader(new FileReader(new File(aFilename)));
        }
        catch (FileNotFoundException ex)
        {
            log.error("CSV File Not Found {}\n{}", aFilename, ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    @NotNull
    public ModelOrderCsv nextOrder()
    {
        String nextLine = null;
        String[] items = CsvUtils.ITEMS_DUMMY;

        try
        {
            while (!isValidCsvLine(items))
            {
                nextLine = theBufferedReader.readLine();

                if (nextLine == null)
                {
                    break;
                }

                items = nextLine.split(",");
            }
        }
        catch (IOException ex)
        {
            log.error("Problem reading csv file {}", ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }

        boolean isActive = (nextLine != null);

        if (!isActive)
        {
            try
            {
                log.info("Closing BufferedReader");
                theBufferedReader.close();
            }
            catch (IOException ex)
            {
                log.error("Problem closing csv file {}", ex.getMessage());
                throw new RuntimeException(ex.getMessage());
            }
        }

        return isActive ? parseModelOrderCsv(items) : ModelOrderCsv.EOF_MODELORDERCSV;
    }

    /**
     * CSV lines are not processed if
     * wrong number of items,
     * an expected header or
     * begins with comment string
     *
     * @param items The split items from a csv line
     * @return Return true if expected csv data format
     */
    private static boolean isValidCsvLine(@NotNull String[] items)
    {
        return (items.length == ITEMS_PER_LINE) &&
            !items[0].trim().equals(FIRST_HEADER) &&
            !items[0].trim().startsWith(CSV_COMMENT);
    }

    /**
     * The 'partial' ModelOrder, needs to be filled in with
     * action based on position in a JIT fashion
     *
     * @param items The split items list from the valid csv line
     * @return Returns a ModelOrderCsv, essentially a ModelOrder
     * without action filled in
     */
    @NotNull
    private static ModelOrderCsv parseModelOrderCsv(@NotNull String[] items)
    {
        return new ModelOrderCsv(
            OmsModelFactory.ModelOrderBaseBuild(
                items[0],
                Integer.parseInt(items[1].trim()),
                items[2].trim(),
                items[3].trim(),
                Integer.parseInt(items[6].trim()),
                CsvUtils.parsePrice4(items[7])),
            items[5].trim(),
            items[4].trim().toLowerCase().startsWith("t"));
    }
}

package com.octillion;

import com.octillion.OmsModels.ModelFill;
import com.octillion.OmsModels.ModelOrder;
import com.octillion.OmsModels.ModelSOD;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeoutException;

public class OmsServerRabbitMQ implements IOmsServer
{
    private static Logger log = LoggerFactory.getLogger(OmsServerRabbitMQ.class);

    private final static String QUEUENAME_SOD = "OmsSod";
    private final static String QUEUENAME_ORDERS = "OmsOrders";
    private final static String QUEUENAME_FILLS = "OmsFills";

    private final SettingsRabbitMQ theSettingsRabbitMQ;

    private Connection theConnection;
    private Channel theChannel;

    public OmsServerRabbitMQ(SettingsRabbitMQ aSettingsRabbitMQ)
    {
        log.info("OmsServerRabbitMQ()");

        theSettingsRabbitMQ = aSettingsRabbitMQ;

        declareQueues(Arrays.asList(QUEUENAME_SOD, QUEUENAME_ORDERS, QUEUENAME_FILLS));
    }

    @NotNull
    private Connection getConnection()
    {
        if (theConnection == null)
        {
            ConnectionFactory factory = new ConnectionFactory();
            // "guest"/"guest" is limited to localhost connections
            factory.setUsername(theSettingsRabbitMQ.UserName);
            factory.setPassword(theSettingsRabbitMQ.UserPass);
            factory.setVirtualHost(theSettingsRabbitMQ.VirtualHost);
            factory.setHost(theSettingsRabbitMQ.Hostname);
            factory.setPort(theSettingsRabbitMQ.Port);

            try
            {
                theConnection = factory.newConnection();
            }
            catch (IOException | TimeoutException ex)
            {
                theConnection = null;

                log.error("Failed to establish CONNECTION to RabbitMQ using {}\n{}",
                    theSettingsRabbitMQ,
                    ex.getMessage());

                throw new RuntimeException(ex.getMessage());
            }

            log.info("Established CONNECTION to RabbitMQ using {}", theSettingsRabbitMQ);
        }

        return theConnection;
    }

    @NotNull
    private Channel getChannel()
    {
        if (theChannel == null)
        {
            try
            {
                theChannel = getConnection().createChannel();
            }
            catch (IOException ex)
            {
                theChannel = null;

                log.error("Failed to establish CHANNEL on RabbitMQ using {}\n{}",
                    theSettingsRabbitMQ,
                    ex.getMessage());

                throw new RuntimeException(ex.getMessage());
            }

            log.info("Established CHANNEL on RabbitMQ using {}", theSettingsRabbitMQ);
        }

        return theChannel;
    }

    private void declareQueues(@NotNull List<String> aQueueNames)
    {
        aQueueNames.forEach(name ->
        {
            try
            {
                getChannel().queueDeclare(name, true, false, false, null);
                getChannel().queueBind(name, theSettingsRabbitMQ.ExchangeDirect, name);
                getChannel().queuePurge(name);
            }
            catch (IOException ex)
            {
                log.error("Failed to declare queue {} on Exchange {}\n{}",
                    name,
                    theSettingsRabbitMQ.ExchangeDirect,
                    ex.getMessage());

                throw new RuntimeException(ex.getMessage());
            }

            log.info("Declared queue {} on Exchange {}",
                name,
                theSettingsRabbitMQ.ExchangeDirect);
        });
    }

    @Override
    public void sendSOD(@NotNull ModelSOD aModelSOD)
    {
        sendMessage(QUEUENAME_SOD, aModelSOD.toByteArray());
    }

    @Override
    public void sendOrder(@NotNull ModelOrder modelOrder)
    {
        sendMessage(QUEUENAME_ORDERS, modelOrder.toByteArray());
    }

    @Override
    public void sendFill(@NotNull ModelFill modelFill)
    {
        sendMessage(QUEUENAME_FILLS, modelFill.toByteArray());
    }

    private void sendMessage(@NotNull String aQueueName, @NotNull byte[] aBytes)
    {
        try
        {
            getChannel().basicPublish(theSettingsRabbitMQ.ExchangeDirect, aQueueName, null, aBytes);
        }
        catch (IOException ex)
        {
            log.error("Failed to send RabbitMQ message on {} queue", aQueueName);
        }
    }

    @Override
    public void close()
    {
        if (theConnection != null)
        {
            try
            {
                getConnection().close();
            }
            catch (IOException ex)
            {
                log.error("Failed to close connection for RabbitMQ using {}\n{}",
                    theSettingsRabbitMQ,
                    ex.getMessage());
            }
        }
    }
}

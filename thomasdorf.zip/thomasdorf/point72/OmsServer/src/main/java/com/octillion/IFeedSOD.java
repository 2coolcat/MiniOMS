package com.octillion;

import com.octillion.OmsModels.ModelSOD;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

public interface IFeedSOD
{
    void runFeed(@NotNull Consumer<ModelSOD> aConsumerSendSOD,
                 @NotNull Consumer<ModelSOD> aConsumerStateSOD);
}

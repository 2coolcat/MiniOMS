package com.octillion;

import com.octillion.OmsModels.ModelFill;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

public class FeedFillCsv implements IFeedFill
{
    private static Logger log = LoggerFactory.getLogger(FeedFillCsv.class);

    private static int ITEMS_PER_LINE = 5;
    /**
     * tradeDateUTC
     */
    private static String FIRST_HEADER = ModelFill.getDescriptor().getFields().get(0).getName();
    private static String CSV_COMMENT = "#";

    private BufferedReader theBufferedReader;

    FeedFillCsv(@NotNull String aFilename)
    {
        try
        {
            theBufferedReader = new BufferedReader(new FileReader(new File(aFilename)));
        }
        catch (FileNotFoundException ex)
        {
            log.error("CSV File Not Found {}\n{}", aFilename, ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }
    }

    @Override
    @NotNull
    public ModelFillCsv nextFill()
    {
        String nextLine = null;
        String[] items = CsvUtils.ITEMS_DUMMY;

        try
        {
            while (!isValidCsvLine(items))
            {
                nextLine = theBufferedReader.readLine();

                if (nextLine == null)
                {
                    break;
                }

                items = nextLine.split(",");
            }
        }
        catch (IOException ex)
        {
            log.error("Problem reading csv file {}", ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }

        boolean isActive = (nextLine != null);

        if (!isActive)
        {
            try
            {
                log.info("Closing BufferedReader");
                theBufferedReader.close();
            }
            catch (IOException ex)
            {
                log.error("Problem closing csv file {}", ex.getMessage());
                throw new RuntimeException(ex.getMessage());
            }
        }

        return isActive ? parseModelFillCsv(items) : ModelFillCsv.EOF_MODELFILLCSV;
    }

    /**
     * CSV lines are not processed if
     * wrong number of items,
     * an expected header or
     * begins with comment string
     *
     * @param items The split items from a csv line
     * @return Return true if expected csv data format
     */
    private static boolean isValidCsvLine(@NotNull String[] items)
    {
        return (items.length == ITEMS_PER_LINE) &&
            !items[0].trim().equals(FIRST_HEADER) &&
            !items[0].trim().startsWith(CSV_COMMENT);
    }

    /**
     * The 'partial' ModelFill, needs to be filled in with
     * current position in a JIT fashion
     *
     * @param items The split items list from the valid csv line
     * @return Returns a ModelFillCsv, essentially a ModelFill
     * without positionBook filled in
     */
    @NotNull
    private static ModelFillCsv parseModelFillCsv(@NotNull String[] items)
    {
        return new ModelFillCsv(
            OmsModelFactory.ModelFillBaseBuild(
                items[0],
                Integer.parseInt(items[1].trim()),
                items[2].trim(),
                items[3].trim(),
                Integer.parseInt(items[4].trim())));
    }
}

package com.octillion;

import com.octillion.OmsModels.ModelFill;
import org.jetbrains.annotations.NotNull;
/**
 * A wrapper class to indicate that the position information is incomplete
 */
class ModelFillCsv
{
    static ModelFillCsv EOF_MODELFILLCSV;

    static
    {
        EOF_MODELFILLCSV = new ModelFillCsv(
            ModelFill.newBuilder()
                .setTradeDateUTC(Long.MAX_VALUE)
                .setOrderId(0)
                .setBookName("")
                .setTicker("")
                .setSharesFilled(0)
                .setPositionBook(0)
                .build());
    }

    private ModelFill theModelFill;

    @NotNull
    ModelFill getModelFill()
    {
        return theModelFill;
    }

    boolean isEOF()
    {
        return (theModelFill.getTradeDateUTC() == Long.MAX_VALUE);
    }

    ModelFillCsv(@NotNull ModelFill aModelFill)
    {
        theModelFill = aModelFill;
    }
}

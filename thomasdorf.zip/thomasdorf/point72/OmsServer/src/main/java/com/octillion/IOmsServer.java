package com.octillion;

import com.octillion.OmsModels.ModelFill;
import com.octillion.OmsModels.ModelOrder;
import com.octillion.OmsModels.ModelSOD;
import org.jetbrains.annotations.NotNull;

public interface IOmsServer
{
    void sendSOD(@NotNull ModelSOD modelSOD);
    void sendOrder(@NotNull ModelOrder modelOrder);
    void sendFill(@NotNull ModelFill modelFill);
    void close();
}

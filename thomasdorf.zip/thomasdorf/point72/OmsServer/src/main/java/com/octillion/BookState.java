package com.octillion;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

class BookState
{
    private final String theBookName;
    private final Map<String, TickerState> theStateByTicker;

    BookState(@NotNull String aBookName)
    {
        theBookName = aBookName;
        theStateByTicker = new HashMap<>();
    }

    @NotNull
    TickerState getOrCreateTickerState(@NotNull String aTicker)
    {
        return theStateByTicker.computeIfAbsent(aTicker, TickerState::new);
    }

    @Nullable
    TickerState getTickerState(@NotNull String aTicker)
    {
        return theStateByTicker.getOrDefault(aTicker, null);
    }
}

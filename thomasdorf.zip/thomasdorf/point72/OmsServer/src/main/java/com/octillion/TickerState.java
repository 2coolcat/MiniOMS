package com.octillion;

import com.octillion.OmsModels.ModelFill;
import com.octillion.OmsModels.ModelOrder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class TickerState
{
    private static Logger log = LoggerFactory.getLogger(TickerState.class);

    private String theTicker;

    void setPosition(int aPosition)
    {
        thePosition = aPosition;
    }

    private int thePosition;
    private Map<Integer, ModelOrder> theOrdersById;

    Map<Integer, ModelOrder> getOrdersById()
    {
        return theOrdersById;
    }

    public TickerState(@NotNull String aTicker, int aPosition)
    {
        theTicker = aTicker;
        thePosition = aPosition;
        theOrdersById = new HashMap<>();
    }

    public TickerState(@NotNull String aTicker)
    {
        this(aTicker, 0);
    }

    /**
     * Process Order by setting the Action related to current position
     * @param aModelOrderCsv The ModelOrder WITHOUT action field set
     *                       along with side and cancel info
     * @return Returns the modified ModelOrder with action field set
     */
    @Nullable
    ModelOrder processOrderCsv(@NotNull ModelOrderCsv aModelOrderCsv)
    {
        final ModelOrder modelOrder;

        if (aModelOrderCsv.isCancel())
        {
            ModelOrder modelOrderExisting = theOrdersById.getOrDefault(
                aModelOrderCsv.getModelOrder().getOrderId(),
                null);

            if (modelOrderExisting == null)
            {
                log.error("Unexpected CANCEL Order {}", aModelOrderCsv.getModelOrder());
                modelOrder = null;
            }
            else
            {
                modelOrder = ModelOrder.newBuilder(modelOrderExisting)
                    .setAction(ModelOrder.EnumAction.CANCELLED)
                    .build();
            }
        }
        else
        {
            modelOrder = ModelOrder.newBuilder(aModelOrderCsv.getModelOrder())
                .setSide(OmsModelFactory.enumSideFromString(aModelOrderCsv.getSide()))
                .setAction(Action(
                    aModelOrderCsv.getSide(),
                    aModelOrderCsv.getModelOrder().getSharesOrder(),
                    thePosition))
                .build();

            if (theOrdersById.containsKey(modelOrder.getOrderId()))
            {
                // Choosing to replace existing Order with duplicate
                log.error("Unexpected DUPLICATE Order {}", modelOrder);
            }
        }

        if (modelOrder != null)
        {
            theOrdersById.put(modelOrder.getOrderId(), modelOrder);
        }

        return modelOrder;
    }

    @NotNull
    private static ModelOrder.EnumAction Action(
        @NotNull String aSide,
        int aShares,
        int aPosition)
    {
        ModelOrder.EnumAction action;

        boolean isBuy = aSide.trim().toLowerCase().startsWith("b");
        boolean isSell = aSide.trim().toLowerCase().startsWith("s");

        if (!isBuy && !isSell)
        {
            log.error("Poorly formatted Side '{}'", aSide);
            throw new RuntimeException(String.format("Poorly formatted Side '%s'", aSide));
        }

        int volume =  isBuy? aShares : -aShares;
        boolean isLongAfterFill = ((aPosition + volume) > 0);
        boolean isShortAfterFill = ((aPosition + volume) < 0);

        return isBuy ?
            isLongAfterFill ?
                ModelOrder.EnumAction.BUYLONG :
                ModelOrder.EnumAction.BUYCOVER :
            isShortAfterFill ?
                ModelOrder.EnumAction.SELLSHORT :
                ModelOrder.EnumAction.SELLLONG;
    }

    /**
     * Detect Overfills: Modify position regardless
     * Reject unexpected Fills before Orders
     * Update the Order.sharesToGo based on Fill amount
     *
     * @param aModelFillCsv The ModelFill without positionBook yet filled in
     * @return Returns a completed ModelFill for sending
     */
    @Nullable
    ModelFill processFillCsv(@NotNull ModelFillCsv aModelFillCsv)
    {
        ModelFill modelFill = null;
        ModelOrder modelOrder = theOrdersById.getOrDefault(aModelFillCsv.getModelFill().getOrderId(), null);

        if (modelOrder == null)
        {
            log.error("REJECTING Unexpected Fill (missing OrderId) {}.", aModelFillCsv.getModelFill());
        }
        else
        {
            int positionDelta = OmsModelFactory.positionDeltaFromOrder(
                modelOrder,
                aModelFillCsv.getModelFill().getSharesFilled());

            thePosition += positionDelta;

            modelFill = ModelFill.newBuilder(aModelFillCsv.getModelFill())
                .setPositionBook(thePosition)
                .build();

            int sharesToGo = modelOrder.getSharesToGo() - aModelFillCsv.getModelFill().getSharesFilled();

            theOrdersById.put(
                modelFill.getOrderId(),
                ModelOrder.newBuilder(modelOrder)
                    .setAction(actionFromSharesToGo(modelOrder, sharesToGo))
                    .setSharesToGo(Math.max(0, sharesToGo))
                    .build());
        }

        return modelFill;
    }

    @NotNull
    private static ModelOrder.EnumAction actionFromSharesToGo(
        @NotNull ModelOrder aModelOrder,
        int aSharesToGo)
    {
        ModelOrder.EnumAction enumAction = aModelOrder.getAction();

        if (aSharesToGo == 0)
        {
            log.info("Order {} marked COMPLETE", aModelOrder.getOrderId());
            enumAction = ModelOrder.EnumAction.COMPLETE;
        }
        else if (aSharesToGo < 0)
        {
            log.error("Order {} marked OVERFILL", aModelOrder.getOrderId());
            enumAction = ModelOrder.EnumAction.OVERFILL;
        }

        return enumAction;
    }
}

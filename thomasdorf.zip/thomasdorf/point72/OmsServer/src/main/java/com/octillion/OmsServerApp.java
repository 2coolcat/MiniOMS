package com.octillion;

import java.util.Scanner;

// docker run -d -p 5672:5672 -p 15672:15672 --hostname dockRabbit --name some-rabbit rabbitmq:3-management

public class OmsServerApp
{
    private static String DEFAULT_SETTINGS_FILE = "SettingsOmsServer.json";

    public static void main(String[] args)
    {
        String settingFile = (args.length == 1) ? args[0] : DEFAULT_SETTINGS_FILE;
        System.out.printf("OmsServer is Running with Settings File: %s\n", settingFile);
        SettingsOmsServer settingsOmsServer = SettingsOmsServer.FromJson(settingFile);
        System.out.println(settingsOmsServer.toString());

        OmsServerEngine engine = new OmsServerEngine(
            new FeedSODCsv(settingsOmsServer.CvsFileSOD),
            new FeedOrderCsv(settingsOmsServer.CvsFileOrders),
            new FeedFillCsv(settingsOmsServer.CvsFileFills),
            new OmsServerRabbitMQ(settingsOmsServer.SettingsRabbitMQ),
            settingsOmsServer.EngineUpdatePeriodMillis);

        engine.start();
        System.out.println("Waiting for OmsServerEngine to finish...");
        engine.waitToFinish();

        System.out.println("Main Thread EXITS");
    }

    private static void waitForUserExit()
    {
        Scanner sc = new Scanner(System.in);

        String input = "";

        while (!input.equalsIgnoreCase("q"))
        {
            System.out.print("<'Q' or 'q' to exit>: ");
            input = sc.next();
        }
    }
}

package com.octillion;

import org.jetbrains.annotations.NotNull;

public interface IFeedOrder
{
    @NotNull
    ModelOrderCsv nextOrder();
}

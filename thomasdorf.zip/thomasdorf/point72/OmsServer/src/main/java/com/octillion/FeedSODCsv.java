package com.octillion;

import com.octillion.OmsModels.ModelSOD;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class FeedSODCsv implements IFeedSOD
{
    private static Logger log = LoggerFactory.getLogger(FeedSODCsv.class);

    /**
     * Send to signal the end of all SOD
     */
    private static final ModelSOD END_OF_FEED;
    private static int ITEMS_PER_LINE = 4;
    private static String CSV_COMMENT = "#";

    /**
     * busDateUTC
     */
    private static String FIRST_HEADER = ModelSOD.getDescriptor().getFields().get(0).getName();

    private String theFilename;

    static
    {
        END_OF_FEED = ModelSOD.newBuilder()
            .setBusDateUTC(0L)
            .setBookName("")
            .setTicker("")
            .setPositionBook(0)
            .build();
    }

    FeedSODCsv(@NotNull String aFilename)
    {
        theFilename = aFilename;
    }

    /**
     * CSV lines are not processed if
     * wrong number of items,
     * an expected header or
     * begins with comment string
     * @param items The split items from a csv line
     * @return Return true if expected csv data format
     */
    private static boolean isValidCsvLine(@NotNull String[] items)
    {
        return
            (items.length == ITEMS_PER_LINE) &&
            !items[0].trim().equals(FIRST_HEADER) &&
            !items[0].trim().startsWith(CSV_COMMENT);
    }

    @Override
    public void runFeed(
        @NotNull Consumer<ModelSOD> aConsumerSendSOD,
        @NotNull Consumer<ModelSOD> aConsumerStateSOD)
    {
        try
        {
            try (Stream<String> stream = Files.lines(Paths.get(theFilename)))
            {
                stream.forEach(line ->
                {
                    String[] items = line.split(",");

                    if (isValidCsvLine(items))
                    {
                        ModelSOD modelSOD = ModelSOD.newBuilder()
                            .setBusDateUTC(CsvUtils.parseDateToEpochSeconds(items[0]))
                            .setBookName(items[1].trim())
                            .setTicker(items[2].trim())
                            .setPositionBook(Integer.parseInt(items[3].trim()))
                            .build();

                        aConsumerSendSOD.accept(modelSOD);
                        aConsumerStateSOD.accept(modelSOD);
                    }
                });
            }

            // Mark end of SOD Transmission
            aConsumerSendSOD.accept(END_OF_FEED);
        }
        catch(IOException ex)
        {
            log.error("Could not find SOD file {}", theFilename);
            throw new RuntimeException(ex.getMessage());
        }
    }
}

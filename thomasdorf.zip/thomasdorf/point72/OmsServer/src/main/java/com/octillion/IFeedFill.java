package com.octillion;

import org.jetbrains.annotations.NotNull;

public interface IFeedFill
{
    @NotNull
    ModelFillCsv nextFill();
}

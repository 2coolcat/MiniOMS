package com.octillion;

import com.octillion.OmsModels.ModelOrder;
import org.jetbrains.annotations.NotNull;

/**
 * After reading csv line we have a partially constructed model order
 * without a correct action. We need to pass this to the engine to
 * process against the current TickerState for the given book
 */
class ModelOrderCsv
{
    static ModelOrderCsv EOF_MODELORDERCSV;

    static
    {
        EOF_MODELORDERCSV = new ModelOrderCsv(
            ModelOrder.newBuilder()
                .setTradeDateUTC(Long.MAX_VALUE)
                .setOrderId(0)
                .setBookName("")
                .setTicker("")
                .setAction(ModelOrder.EnumAction.UNDEF_ACTION)
                .setSide(ModelOrder.EnumSide.UNDEF_SIDE)
                .setSharesOrder(0)
                .setSharesToGo(0)
                .setPrice4(0)
                .build(),
            "",
            false);
    }

    private ModelOrder theModelOrder;
    private String theSide;
    private boolean theIsCancel;

    ModelOrderCsv(
        @NotNull ModelOrder aModelOrder,
        @NotNull String aSide,
        boolean aIsCancel)
    {
        theModelOrder = aModelOrder;
        theSide = aSide;
        theIsCancel = aIsCancel;
    }

    @NotNull
    ModelOrder getModelOrder()
    {
        return theModelOrder;
    }

    @NotNull
    String getSide()
    {
        return theSide;
    }

    boolean isCancel()
    {
        return theIsCancel;
    }

    boolean isEOF()
    {
        return (theModelOrder.getTradeDateUTC() == Long.MAX_VALUE);
    }
}

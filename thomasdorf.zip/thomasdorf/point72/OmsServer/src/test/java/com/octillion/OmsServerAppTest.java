package com.octillion;

import com.octillion.OmsModels.ModelFill;
import com.octillion.OmsModels.ModelOrder;
import com.octillion.OmsModels.ModelSOD;
import org.jetbrains.annotations.NotNull;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class OmsServerAppTest
{
    /**
     * Date and DateTime are sent in protobuf using UTC seconds long value
     * String Timestamps in CSV files are assumed to be in Local Time Zone
     */
    @Test
    public void DateTimeTest()
    {
        long epoch20200227Sec = 1582779600L;

        assertEquals(epoch20200227Sec, CsvUtils.parseDateToEpochSeconds("2020-02-27"));

        assertEquals(
            "2020-02-27T00:00",
            Instant.ofEpochSecond(epoch20200227Sec).atZone(ZoneId.systemDefault()).toLocalDateTime().toString());

        assertEquals(epoch20200227Sec, CsvUtils.parseDateTimeToEpochSeconds("2020-02-27 00:00:00"));
        assertEquals(epoch20200227Sec + 1L, CsvUtils.parseDateTimeToEpochSeconds("2020-02-27 00:00:01"));
    }

    @Test
    public void TickerStateActionTest()
    {
        ModelOrder modelOrderIn = OmsModelFactory.ModelOrderBaseBuild(
            "2020-02-27 10:00:00",
            1,
            "BookTest",
            "TICKERTEST",
            500,
            10100);

        assertEquals(
            ModelOrder.newBuilder(modelOrderIn).setAction(ModelOrder.EnumAction.BUYLONG).build(),
            new TickerState("IBM", -499).processOrderCsv(new ModelOrderCsv(modelOrderIn, "BUY", false)));

        assertEquals(
            ModelOrder.newBuilder(modelOrderIn).setAction(ModelOrder.EnumAction.BUYCOVER).build(),
            new TickerState("IBM", -500).processOrderCsv(new ModelOrderCsv(modelOrderIn, "BUY", false)));

        assertEquals(
            ModelOrder.newBuilder(modelOrderIn).setAction(ModelOrder.EnumAction.SELLSHORT).build(),
            new TickerState("IBM", 499).processOrderCsv(new ModelOrderCsv(modelOrderIn, "SELL", false)));

        assertEquals(
            ModelOrder.newBuilder(modelOrderIn).setAction(ModelOrder.EnumAction.SELLLONG).build(),
            new TickerState("IBM", 500).processOrderCsv(new ModelOrderCsv(modelOrderIn, "SELL", false)));

        // This outputs an expected ERROR for Unexpected CANCEL Order, nonetheless checks setting of action
        assertEquals(
            ModelOrder.newBuilder(modelOrderIn).setAction(ModelOrder.EnumAction.CANCELLED).build(),
            new TickerState("IBM", 500).processOrderCsv(new ModelOrderCsv(modelOrderIn, "", true)));
    }

    class OmsServerMock implements IOmsServer
    {
        private Logger log = LoggerFactory.getLogger(OmsServerMock.class);

        List<String> theHistory = new ArrayList<>();

        private void addHistory(String aMsg)
        {
            log.info(aMsg);
            theHistory.add(aMsg);
        }

        void dumpHistoryToFile(String aFile)
        {
            try
            {
                PrintWriter out = new PrintWriter(aFile, "UTF-8");
                theHistory.forEach(out::println);
                out.close();
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }

        @Override
        public void sendSOD(@NotNull ModelSOD modelSOD)
        {
            addHistory(String.format("sendSOD %s", modelSOD.toString()));
        }

        @Override
        public void sendOrder(@NotNull ModelOrder modelOrder)
        {
            addHistory(String.format("sendOrder %s", modelOrder.toString()));
        }

        @Override
        public void sendFill(@NotNull ModelFill modelFill)
        {
            addHistory(String.format("sendFill %s", modelFill.toString()));
        }

        @Override
        public void close()
        {
            addHistory("close");
        }
    }

    @Test
    public void TickerStateTest()
    {
        OmsServerMock mock = new OmsServerMock();

        OmsServerEngine engine = new OmsServerEngine(
            new FeedSODCsv("src/test/resources/gen.SOD.csv"),
            new FeedOrderCsv("src/test/resources/gen.Orders.csv"),
            new FeedFillCsv("src/test/resources/gen.Fills.csv"),
            mock,
            1);

        engine.start();
        engine.waitToFinish();

        mock.dumpHistoryToFile("src/test/resources/outTickerStateTest.txt");

        // Verify mock against expected output
        assertTrue(simpleFileCompare(
            "src/test/resources/outTickerStateTest.txt",
            "src/test/resources/refTickerStateTest.txt"));
    }

    /**
     * Only appropriate for smaller files
     * @param aFile1
     * @param aFile2
     * @return Returns true if files are byte identical
     */
    private boolean simpleFileCompare(String aFile1, String aFile2)
    {
        boolean success = false;

        try
        {
            success = Arrays.equals(
                Files.readAllBytes(new File(aFile1).toPath()),
                Files.readAllBytes(new File(aFile2).toPath()));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }

        return success;
    }
}

#!/bin/bash
./build_csharp.sh
./build_java.sh

#!/bin/bash
#'C:\bin\protoc-3.9.1-win64\bin\protoc' --java_out='generated\java' pokerModels.proto
'C:\bin\protoc-3.9.1-win64\bin\protoc' --java_out='..\OmsServer\src\main\java' OmsModels.proto
'C:\bin\protoc-3.9.1-win64\bin\protoc' --java_out='..\MDServer\src\main\java' OmsModels.proto

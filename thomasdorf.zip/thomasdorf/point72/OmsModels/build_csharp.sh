#!/bin/bash
#'C:\bin\protoc-3.9.1-win64\bin\protoc' --java_out='generated\java' pokerModels.proto
'C:\bin\protoc-3.9.1-win64\bin\protoc' --csharp_out='..\OmsView' OmsModels.proto
